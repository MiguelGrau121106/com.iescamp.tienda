package iescamp.tienda;

import iescamp.tienda.modelo.Usuarios.Cliente;
import iescamp.tienda.modelo.Usuarios.Empleado;
import iescamp.tienda.modelo.Usuarios.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class InfoUsuarioController implements Refrescable {
    @FXML
    public Label lbNombreApellidos,lbDNI,lbFechaNac,lbTlf,lbDirec,lbEmail,lbTarjetaFid,lbNumPedidos,lbDirecEnvio;

    @FXML
    private VBox vboxPrincipal;

    @FXML
    private GridPane grid;

    public void refrescar() {

        cargarContenido();

    }

    public void cargarContenido() {

        // Establecer el estilo del VBox
        vboxPrincipal.setStyle("""
                -fx-background-color: linear-gradient(to bottom right, white, lightskyblue);
                -fx-padding: 20px;
                -fx-spacing: 10px;
                """);
        //tamaño del grid pane

        grid.setPrefSize(vboxPrincipal.getWidth(), vboxPrincipal.getHeight());





        Usuario usuario = SessionManager.getInstancia().getUsuario();
        lbNombreApellidos.setText(usuario.getNombre() + " " + usuario.getApellidos());
        lbDNI.setText("DNI: " + usuario.getDNI());
        lbFechaNac.setText("Fecha de nacimiento: " + usuario.getFechaNacimiento().toString());
        lbTlf.setText("Número de teléfono: " + usuario.getTelefono());
        lbDirec.setText("Dirección: " + usuario.getDireccion());
        lbEmail.setText("Email: " + usuario.getCorreoElectronico());


        if (usuario instanceof Cliente) {
            Cliente cliente = (Cliente) usuario;
            lbNumPedidos.setText("Número de pedidos: " + ((Cliente) usuario).getNumeroPedidosRealizados());
            if (cliente.getDireccionEnvio() == null)
                lbDirecEnvio.setText("No tiene dirección de envío");
            else
                lbDirecEnvio.setText(cliente.getDireccionEnvio());

            if (cliente.isTieneTarjetaFidelidad())
                lbTarjetaFid.setText("Tiene tarjeta de fidelización");
            else
                lbTarjetaFid.setText("No tiene tarjeta de fidelización");
        } else if (usuario instanceof Empleado) {
            lbNumPedidos.setText("Departamento: " + ((Empleado) usuario).getDepartamento().getNombre());
            lbDirecEnvio.setText("");
            lbTarjetaFid.setText("");
        }





    }


    public void onLogin(ActionEvent actionEvent) {

            SessionManager.getInstancia().cerrarSesion();


    }
}
