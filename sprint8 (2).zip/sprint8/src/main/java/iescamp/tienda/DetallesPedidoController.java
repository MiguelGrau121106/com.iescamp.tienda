package iescamp.tienda;

import iescamp.tienda.modelo.Articulos.Accesorio;
import iescamp.tienda.modelo.Articulos.Articulo;
import iescamp.tienda.modelo.Articulos.Ropa;
import iescamp.tienda.modelo.Pedidos.LineaPedido;
import iescamp.tienda.modelo.Pedidos.Pedido;
import iescamp.tienda.modelo.dao.DBUtil;
import iescamp.tienda.modelo.dao.PedidoDAO;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;

import java.io.IOException;
import java.sql.SQLException;


public class DetallesPedidoController implements Refrescable{


    public void refrescar(){
        cargarContenido();
    }

    @FXML
    private VBox contenedorPrincipal;

    @FXML
    private VBox contenedorItems;

    @FXML
    private ScrollPane scrollPane;

    @FXML
    private HBox header;

    @FXML
    private Label lbPrecio;

    private GridPane grid = new GridPane();

    private Pedido pedido = SessionManager.getInstancia().getPedido();

    public void cargarContenido() {

        contenedorItems.getChildren().clear();
        contenedorItems.getChildren().add(grid);
        contenedorPrincipal.setStyle("""
        -fx-background-color: linear-gradient(to bottom right, white, lightskyblue);
        """);
        contenedorPrincipal.setMinHeight(Screen.getPrimary().getBounds().getHeight());
        contenedorPrincipal.setAlignment(Pos.TOP_CENTER);
        grid.getChildren().clear();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));
        grid.setAlignment(Pos.CENTER);

        PedidoDAO pedidoDAO = new PedidoDAO();
        try {
            pedido.setLineasPedido(pedidoDAO.obtenerLineasPedido(pedido.getNumeroPedido(), DBUtil.getConnection()));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        if (pedido == null || pedido.getLineasPedido() == null || pedido.getLineasPedido().isEmpty()) {
            System.out.println("No hay lineas de pedido. ");
           ;
        } else {
            System.out.println("Hay lineas de pedido: " + pedido.getLineasPedido().size());


            calcularPrecioTotal();

             int fila = 0;
            int columna = 0;



            for (LineaPedido linea : pedido.getLineasPedido()) {


                cargarArticulos(linea, columna, fila);


                columna++;
                if (columna == 3) {
                    columna = 0;
                    fila++;
                }

            }
        }


    }


    public void calcularPrecioTotal() {
        double precioTotal = 0;
        for (LineaPedido linea : pedido.getLineasPedido()) {
            precioTotal += linea.getArticulo().getPrecio();
        }
        lbPrecio.setText("Precio Total: " + precioTotal + " €");
    }

    public void cargarArticulos(LineaPedido linea, int columna, int fila) {


        Articulo articulo = linea.getArticulo();





            if (articulo instanceof Ropa) {

                Ropa ropa = (Ropa) articulo;
                VBox tarjeta = new VBox(5);
                tarjeta.setPadding(new Insets(10));
                tarjeta.setAlignment(Pos.CENTER);
                Label nombre = new Label(ropa.getNombre());
                System.out.println(ropa.getImagen());
                java.net.URL imageUrl = getClass().getResource("/images/" + ropa.getImagen());
                if (imageUrl != null) {
                    Image imagen = new Image(imageUrl.toExternalForm());
                    ImageView imageView = new ImageView(imagen);
                    imageView.setFitWidth(600);
                    imageView.setFitHeight(600);
                    imageView.setPreserveRatio(true);
                    imageView.setOnMouseClicked( e -> {
                        SessionManager.getInstancia().setArticuloSeleccionado(articulo);
                        onProducto();
                    });
                    Label precio = new Label(String.valueOf(ropa.getPrecio()));
                    Button anyadirAlCarrito = new Button("Añadir al carrito");
                    anyadirAlCarrito.setOnAction(e -> System.out.println("Acceso a: " + ropa.getNombre()));
                    tarjeta.getChildren().addAll(imageView, nombre, precio, anyadirAlCarrito);
                    estilizarProducto(tarjeta);
                    grid.add(tarjeta, columna, fila);
                } else {
                    System.err.println("Image not found: /images/" + ropa.getImagen());
                }

            } else if (articulo instanceof Accesorio) {
                Accesorio accesorio = (Accesorio) articulo;
                VBox tarjeta = new VBox(5);
                tarjeta.setPadding(new Insets(10));
                tarjeta.setAlignment(Pos.CENTER);
                Label nombre = new Label(accesorio.getNombre());
                java.net.URL imageUrl = getClass().getResource("/images/" + accesorio.getImagen());
                if (imageUrl != null) {
                    Image imagen = new Image(imageUrl.toExternalForm());
                    ImageView imageView = new ImageView(imagen);
                    imageView.setFitWidth(600);
                    imageView.setFitHeight(600);
                    imageView.setPreserveRatio(true);
                    Label precio = new Label(String.valueOf(accesorio.getPrecio()));
                    Button anyadirAlCarrito = new Button("Añadir al carrito");
                    anyadirAlCarrito.setOnAction(e -> System.out.println("Acceso a: " + accesorio.getNombre()));
                    tarjeta.getChildren().addAll(imageView, nombre, precio, anyadirAlCarrito);
                    estilizarProducto(tarjeta);
                    grid.add(tarjeta, columna, fila);
                } else {
                    System.err.println("Image not found: /images/tu_imagen.png");
                }


            }


        }

    private void onProducto() {
        try {
            SessionManager.getInstancia().mostrar("producto.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void estilizarProducto(VBox tarjeta) {
        tarjeta.setStyle("""
        -fx-padding: 10;
        -fx-spacing: 8;
    """);

        for (Node nodo : tarjeta.getChildren()) {
            if (nodo instanceof Label label) {
                label.setStyle("""
                -fx-text-fill: black;
                -fx-font-size: 16px;
                -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
                -fx-alignment: center;
            """);
            } else if (nodo instanceof Button boton) {
                boton.setStyle("""
                -fx-background-color: black;
                -fx-border-color: white;
                -fx-text-fill: white;
                -fx-font-size: 14px;
                -fx-padding: 6 12;
                -fx-cursor: hand;
                -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            """);

                boton.setOnMouseEntered(e -> boton.setStyle("""
                -fx-background-color: white;
                -fx-text-fill: black;
                -fx-border-color: black;
                -fx-font-size: 14px;
                -fx-padding: 6 12;
                -fx-cursor: hand;
                -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            """));

                boton.setOnMouseExited(e -> boton.setStyle("""
                -fx-background-color: black;
                -fx-border-color: white;
                -fx-text-fill: white;
                -fx-font-size: 14px;
                -fx-padding: 6 12;
                -fx-cursor: hand;
                -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            """));
            }
        }
    }

    public void onPedidos(MouseEvent mouseEvent) {
        try {
            SessionManager.getInstancia().mostrar("pedidos.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}


