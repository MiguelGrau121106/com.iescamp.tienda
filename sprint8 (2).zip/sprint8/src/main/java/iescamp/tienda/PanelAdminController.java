package iescamp.tienda;

import javafx.scene.input.MouseEvent;

import java.io.IOException;

public class PanelAdminController {
    public void onEditarEmpleado(MouseEvent mouseEvent) {
        try{
            SessionManager.getInstancia().mostrar("editar_empleado.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void onListarUsuarios(MouseEvent mouseEvent) {
        try{
            SessionManager.getInstancia().mostrar("listar_usuarios.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void onAñadirEmpleado(MouseEvent mouseEvent) {
        try{
            SessionManager.getInstancia().mostrar("añadir_empleado.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
