package iescamp.tienda;

import iescamp.tienda.modelo.Pedidos.*;
import iescamp.tienda.modelo.Articulos.Articulo;
import iescamp.tienda.modelo.Usuarios.Cliente;
import iescamp.tienda.modelo.dao.PedidoDAO;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import  iescamp.tienda.modelo.dao.PedidoDAO;

public class PedidosController implements Refrescable {

    @FXML
    private VBox contenedorPedidos;

    @FXML
    private Label placeholderLabel;

    private ArrayList<Pedido> pedidos = new ArrayList<>();
    private Ventas ventas;




    private void cargarPedidos() {
        PedidoDAO pedidoDAO = new PedidoDAO();
        Object usuario = SessionManager.getInstancia().getUsuario();

        if (usuario instanceof Cliente cliente) {
            try {
                pedidos = (ArrayList<Pedido>) pedidoDAO.obtenerPedidosPorCliente(cliente);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } else {
            System.out.println("El usuario actual no es un cliente. No se pueden cargar pedidos.");
            placeholderLabel.setText("Solo los clientes pueden ver pedidos.");
            placeholderLabel.setVisible(true);
            return;
        }

        contenedorPedidos.getChildren().clear();

        if (pedidos == null || pedidos.isEmpty()) {
            System.out.println("No hay pedidos. Mostrando placeholder.");
            placeholderLabel.setVisible(true);
        } else {
            System.out.println("Hay pedidos: " + pedidos.size());
            placeholderLabel.setVisible(false);

            for (Pedido pedido : pedidos) {
                VBox card = new VBox(10);
                card.getStyleClass().add("pedido-card");

                // Cabecera del pedido
                Label numeroPedido = new Label("Pedido #" + pedido.getNumeroPedido());
                numeroPedido.getStyleClass().add("pedido-header");

                Label estado = new Label(pedido.getEstado().getDescripcion());
                estado.getStyleClass().add("estado-label");

                Label fecha = new Label("Fecha: " + pedido.getFechaPedido());

                HBox header = new HBox(10, numeroPedido, estado, fecha);

                // Lista de artículos
                VBox listaArticulos = new VBox(5);
                for (LineaPedido linea : pedido.getLineasPedido()) {
                    Articulo articulo = linea.getArticulo();

                    ImageView imagen = new ImageView(new Image(articulo.getImagen()));
                    imagen.setFitWidth(60);
                    imagen.setFitHeight(60);

                    VBox infoArticulo = new VBox(
                            new Label(articulo.getNombre()),
                            new Label("Marca: " + articulo.getMarca()),
                            new Label("Color: " + articulo.getColor()),
                            new Label("Precio: " + articulo.getPrecio() + " €")
                    );

                    HBox item = new HBox(10, imagen, infoArticulo);
                    item.getStyleClass().add("articulo-item");
                    listaArticulos.getChildren().add(item);
                }

                // Botones
                Button detalleBtn = new Button("Ver Detalle");
                detalleBtn.setOnAction(event -> verDetalles(pedido));
                detalleBtn.getStyleClass().add("boton-detalle");

                Button cancelarBtn = new Button("Cancelar");
                cancelarBtn.getStyleClass().add("boton-cancelar");
                cancelarBtn.setOnAction(event -> {
                    pedido.setEstado(EstadoPedido.CANCELADO);
                    pedidoDAO.actualizar(pedido);
                    cargarPedidos();
                });
                cancelarBtn.setDisable(pedido.getEstado() != EstadoPedido.EN_PROCESO);

                FlowPane botones = new FlowPane(10, 0, detalleBtn, cancelarBtn);

                card.getChildren().addAll(header, listaArticulos, botones);
                contenedorPedidos.getChildren().add(card);
            }
        }
    }


    private void verDetalles(Pedido pedido) {
        try {
            SessionManager.getInstancia().setPedido(pedido);
            SessionManager.getInstancia().mostrar("DetallesPedido.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }




    @Override
    public void refrescar() {
        cargarPedidos();
    }
}
