package iescamp.tienda;

import iescamp.tienda.modelo.Usuarios.Departamento;
import iescamp.tienda.modelo.Usuarios.Empleado;
import iescamp.tienda.modelo.dao.DepartamentoDAO;
import iescamp.tienda.modelo.dao.EmpleadoDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

public class EditarEmpleadoController implements Initializable {

    @FXML
    private CheckBox CheckBoxPriv;

    @FXML
    private DatePicker DpNac;

    @FXML
    private Button btnCancelar;

    @FXML
    private Button btnGuardar;

    @FXML
    private Label txt;

    @FXML
    private TextField txtApellidos;

    @FXML
    private TextField txtContrasenya;

    @FXML
    private TextField txtCorreo;

    @FXML
    private TextField txtDepartamento;

    @FXML
    private TextField txtDireccion;

    @FXML
    private TextField txtDni;

    @FXML
    private TextField txtNombre;


    @FXML
    private TextField txtTelefono;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){

        txtDni.setOnAction(event -> cargarDatosEmpleado());
    }

    private void cargarDatosEmpleado() {
        String dni = txtDni.getText().trim();
        if (dni.isEmpty()) {
            mostrarAlerta(Alert.AlertType.WARNING, "Campo vacío", "Por favor, introduce un DNI.");
            return;
        }

        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        Empleado empleado = empleadoDAO.buscarEmpleadoPorDNI(dni);

        if (empleado != null) {
            txtNombre.setText(empleado.getNombre());
            txtApellidos.setText(empleado.getApellidos());
            txtCorreo.setText(empleado.getCorreoElectronico());
            txtContrasenya.setText(empleado.getPass());
            txtTelefono.setText(empleado.getTelefono());
            txtDireccion.setText(empleado.getDireccion());
            DpNac.setValue(empleado.getFechaNacimiento());
            //txtSalario.setText("");
            CheckBoxPriv.setSelected(false);
            txtDepartamento.setText(empleado.getDepartamento().getNombre());

            if (empleado.isPrivilegio()) {
                CheckBoxPriv.setSelected(true);
            } else {
                CheckBoxPriv.setSelected(false);
            }

        } else {
            mostrarAlerta(Alert.AlertType.ERROR, "Empleado no encontrado", "No se encontró un empleado con el DNI proporcionado.");
        }
    }
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    @FXML
    void guardar(ActionEvent event) {
        String dni = txtDni.getText().trim();
        String nombre = txtNombre.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        String direccion = txtDireccion.getText().trim();
        String email = txtCorreo.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String contrasena = txtContrasenya.getText().trim();
        boolean privilegios = CheckBoxPriv.isSelected();
        String departamento = txtDepartamento.getText().trim();

        // Validaciones básicas
        if (dni.isEmpty() || nombre.isEmpty() || apellidos.isEmpty() || direccion.isEmpty() || email.isEmpty() || telefono.isEmpty() || contrasena.isEmpty()) {
            mostrarAlerta(Alert.AlertType.ERROR, "Campos incompletos", "Por favor, complete todos los campos obligatorios.");
            return;
        }

        if (!esEmailValido(email)) {
            mostrarAlerta(Alert.AlertType.ERROR, "Email inválido", "El formato del correo electrónico es incorrecto.");
            return;
        }

        if (!esDNICorrecto(dni)) {
            mostrarAlerta(Alert.AlertType.ERROR, "DNI inválido", "El DNI debe tener 8 dígitos y una letra.");
            return;
        }
        // Aquí puedes agregar la lógica para guardar el empleado en la base de datos

        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        DepartamentoDAO departamentoDAO = new DepartamentoDAO();

        Departamento departamentoObj = departamentoDAO.obtenerPorNombre(departamento);

        // Verificar si el departamento existe
        if (departamentoObj == null) {
            mostrarAlerta(Alert.AlertType.ERROR, "Departamento no encontrado", "El departamento especificado no existe, creandolo como nuevo departamento." );
            // Crear un nuevo departamento
            departamentoDAO.insertar(new Departamento(0,nombre));
            departamentoObj = departamentoDAO.obtenerPorNombre(nombre);
        }

        // Crear el objeto Empleado
        Empleado empleado = new Empleado(dni, nombre, apellidos, direccion, email, telefono, DpNac.getValue(), contrasena, true, privilegios, departamentoObj);
        empleadoDAO.actualizar(empleado);

        // Mostrar mensaje de éxito
        mostrarAlerta(Alert.AlertType.INFORMATION, "Empleado editado", "Empleado editado correctamente");

    }

    @FXML
    void volver(ActionEvent event) {
        try {
            SessionManager.getInstancia().mostrar("panel_admin.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    private boolean esEmailValido(String email) {
        String regex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        return Pattern.matches(regex, email);
    }

    private boolean esDNICorrecto(String dni) {
        String regex = "^[0-9]{8}[A-Za-z]$";
        return Pattern.matches(regex, dni);
    }

}

