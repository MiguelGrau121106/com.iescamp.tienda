package iescamp.tienda;
import iescamp.tienda.modelo.Articulos.*;
import iescamp.tienda.modelo.dao.AccesorioDAO;
import iescamp.tienda.modelo.dao.ArticuloDAO;
import iescamp.tienda.modelo.dao.RopaDAO;
import javafx.fxml.FXMLLoader;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;
public class CatalogoController implements Refrescable {
    @FXML
    private VBox contenedorItems;

    @FXML
    private HBox contenedorFiltros;

    // ComboBoxes globales
    private ComboBox<String> FiltroTipo = new ComboBox<>();
    private ComboBox<String> FiltroColor = new ComboBox<>();
    private ComboBox<String> FiltroTalla = new ComboBox<>();
    private ComboBox<String> FiltroMaterial = new ComboBox<>();
    private ComboBox<String> FiltroMarca = new ComboBox<>();
    private ComboBox<String> FiltroEstilo = new ComboBox<>();
    private CheckBox FiltroPersonalizado = new CheckBox("Personalizado");
    private ComboBox<String> FiltroCierreBolso = new ComboBox<>();
    private ComboBox<String> FiltroCapacidad = new ComboBox<>();
    private ComboBox<String> FiltroTipoSuela = new ComboBox<>();
    private ComboBox<String> FiltroTallaZapato = new ComboBox<>();
    private ComboBox<String> FiltroCierreRopa = new ComboBox<>();
    private CheckBox FiltroImpermeable = new CheckBox("Impermeable");
    private ComboBox<String> FiltroTipoManga = new ComboBox<>();
    private CheckBox FiltroEstampado = new CheckBox("Estampado");
    private ComboBox<String> FiltroTipoPantalon = new ComboBox<>();
    private CheckBox FiltroBolsillos = new CheckBox("Bolsillos");



    @FXML
    private ScrollPane scrollPane;

    RopaDAO ropaDAO = new RopaDAO();
    AccesorioDAO accesorioDAO = new AccesorioDAO();
    ArticuloDAO articuloDAO = new ArticuloDAO();

    private GridPane grid = new GridPane();
    private List<Articulo> todosLosArticulos = articuloDAO.obtenerTodos();

    private static final int CURSOS_POR_PAGINA = 9;
    private int paginaActual = 0;

    @Override
    public void refrescar() {
        try {
            cargarContenido("Todos");


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void cargarContenido(String tipo) {
        todosLosArticulos = articuloDAO.obtenerTodos();
        // Combo Tipo
        FiltroTipo.getItems().addAll("Todos", "Camisa", "Pantalón", "Chaqueta",  "Zapato", "Bolso");
        FiltroTipo.setValue("Todos");





        FiltroTipo.setOnAction(e -> {
            cargarFiltrosDisponibles();
            aplicarFiltro();
        });


        cargarFiltrosDisponibles();
        aplicarFiltro();
        cargarMasCursos();



        scrollPane.vvalueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.doubleValue() == 1.0) {
                cargarMasCursos();
            }
        });
    }






    private void aplicarFiltro() {
        paginaActual = 0;
        grid.getChildren().clear();
        System.out.println(todosLosArticulos.size());
        todosLosArticulos = articuloDAO.obtenerArticulosFiltrados(FiltroTipo.getValue(), FiltroColor.getValue(), FiltroTalla.getValue(), FiltroMaterial.getValue() , FiltroEstilo.getValue(), FiltroPersonalizado.isSelected(), FiltroCierreBolso.getValue(), FiltroCapacidad.getValue(), FiltroTipoSuela.getValue(), FiltroTallaZapato.getValue(), FiltroCierreRopa.getValue(), FiltroImpermeable.isSelected(), FiltroTipoManga.getValue(), FiltroEstampado.isSelected(), FiltroTipoPantalon.getValue(), FiltroBolsillos.isSelected());
        System.out.println(todosLosArticulos.size());
        cargarMasCursos();
        contenedorItems.getChildren().setAll(grid);
    }

    private void cargarMasCursos() {
        int inicio = paginaActual * CURSOS_POR_PAGINA;
        int fin = Math.min(inicio + CURSOS_POR_PAGINA, todosLosArticulos.size());
        grid.setAlignment(Pos.CENTER);
        int columna = grid.getChildren().size() % 3;
        int fila = grid.getChildren().size() / 3;
        if (todosLosArticulos == null || todosLosArticulos.isEmpty()) {
            Label label = new Label("No hay artículos disponibles :(");
            label.setStyle("-fx-font-size: 30px;");

            grid.getChildren().add(label);


        }


        for (int i = inicio; i < fin; i++) {

            if (todosLosArticulos.get(i) instanceof Ropa) {
                Ropa ropa = (Ropa) todosLosArticulos.get(i);
                VBox tarjeta = new VBox(5);
                tarjeta.setPadding(new Insets(10));
                tarjeta.setAlignment(Pos.CENTER);
                Label nombre = new Label(ropa.getNombre());
                ImageView imagen = new ImageView("https://picsum.photos/seed/" + ropa.getNombre() + "/100/100");
                imagen.setFitWidth(100);
                imagen.setFitHeight(100);
                Label precio = new Label(String.valueOf(ropa.getPrecio()));
                Button anyadirAlCarrito = new Button("Añadir al carrito");
                anyadirAlCarrito.setOnAction(e -> System.out.println("Acceso a: " + ropa.getNombre()));
                tarjeta.getChildren().addAll(imagen, nombre, precio, anyadirAlCarrito);
                grid.add(tarjeta, columna, fila);
                columna++;
                if (columna == 3) {
                    columna = 0;
                    fila++;
                }
            } else if (todosLosArticulos.get(i) instanceof Accesorio) {
                Accesorio accesorio = (Accesorio) todosLosArticulos.get(i);
                VBox tarjeta = new VBox(5);
                tarjeta.setPadding(new Insets(10));
                tarjeta.setAlignment(Pos.CENTER);
                Label nombre = new Label(accesorio.getNombre());
                ImageView imagen = new ImageView("https://picsum.photos/seed/" + accesorio.getNombre() + "/100/100");
                imagen.setFitWidth(100);
                imagen.setFitHeight(100);
                Label precio = new Label(String.valueOf(accesorio.getPrecio()));
                Button anyadirAlCarrito = new Button("Añadir al carrito");
                anyadirAlCarrito.setOnAction(e -> System.out.println("Acceso a: " + accesorio.getNombre()));
                tarjeta.getChildren().addAll(imagen, nombre, precio, anyadirAlCarrito);
                grid.add(tarjeta, columna, fila);
                columna++;
                if (columna == 3) {
                    columna = 0;
                    fila++;
                }
            }
            paginaActual++;
        }
    }

    public void cargarFiltrosDisponibles() {

        GridPane panelFiltros = new GridPane();
        panelFiltros.setAlignment(Pos.CENTER);
        contenedorFiltros.getChildren().clear();
        contenedorFiltros.getChildren().add(panelFiltros);


        panelFiltros.setHgap(10);
        panelFiltros.setVgap(10);
        panelFiltros.setPadding(new Insets(10));
        int columna = 0;
        int fila = 0;
        panelFiltros.add(new Label("Tipo:"), 0, fila);
        panelFiltros.add(FiltroTipo, 1, fila++);
        FiltroColor.getItems().add("Todos");
        FiltroMaterial.getItems().add("Todos");
        FiltroMarca.getItems().add("Todos");
        FiltroTipoManga.getItems().add("Todos");
        FiltroTalla.getItems().add("Todos");
        FiltroCierreRopa.getItems().add("Todos");
        FiltroCierreBolso.getItems().add("Todos");
        FiltroCapacidad.getItems().add("Todos");
        FiltroTipoSuela.getItems().add("Todos");
        FiltroTallaZapato.getItems().add("Todos");
        FiltroTipoPantalon.getItems().add("Todos");
        FiltroEstilo.getItems().add("Todos");
        // Combo Color
        FiltroColor.getItems().clear();
        for (Articulo articulo : todosLosArticulos) {
            if (!FiltroColor.getItems().contains(articulo.getColor())) {
                FiltroColor.getItems().add(articulo.getColor());
            }
        }
        FiltroColor.setOnAction(e -> {
            aplicarFiltro();
        });

        FiltroColor.setValue("Todos");
        panelFiltros.add(new Label("Color:"), 0, fila);
        panelFiltros.add(FiltroColor, 1, fila++);
        // Combo Material
        FiltroMaterial.getItems().clear();

        for (Articulo articulo : todosLosArticulos) {
            if (!FiltroMaterial.getItems().contains(articulo.getMaterial().getDenominacion())) {
                FiltroMaterial.getItems().add(articulo.getMaterial().getDenominacion());
            }
        }
        FiltroMaterial.setOnAction(e -> {
            aplicarFiltro();
        });
        FiltroMaterial.setValue("Todos");
        panelFiltros.add(new Label("Material:"), 0, fila);
        panelFiltros.add(FiltroMaterial, 1, fila++);
        // Combo Marca
        FiltroMarca.getItems().clear();
        for (Articulo articulo : todosLosArticulos) {
            if (!FiltroMarca.getItems().contains(articulo.getMarca())) {
                FiltroMarca.getItems().add(articulo.getMarca());
            }
        }
        FiltroMarca.setOnAction(e -> {
            aplicarFiltro();
        });
        FiltroMarca.setValue("Todos");
        panelFiltros.add(new Label("Marca:"), 0, fila);
        panelFiltros.add(FiltroMarca, 1, fila++);




        if (FiltroTipo.getValue().equals("Camisa") || FiltroTipo.getValue().equals("Pantalón") || FiltroTipo.getValue().equals("Chaqueta")) {
            // Combo talla
            FiltroTalla.getItems().clear();

            for (Articulo articulo : todosLosArticulos) {
                if (articulo instanceof Ropa) {
                    Ropa ropa = (Ropa) articulo;
                    if (!FiltroTalla.getItems().contains(ropa.getTalla())) {
                        FiltroTalla.getItems().add(ropa.getTalla());
                    }
                }
            }

            FiltroTalla.setOnAction(e -> {
                aplicarFiltro();
            });
            FiltroTalla.setValue("Todos");
            panelFiltros.add(new Label("Talla:"), 0, fila);
            panelFiltros.add(FiltroTalla, 1, fila++);

            // Combo Cierre

            FiltroCierreRopa.getItems().clear();
            for (Articulo articulo : todosLosArticulos) {
                if (articulo instanceof Ropa) {
                    Ropa ropa = (Ropa) articulo;
                    if (!FiltroCierreRopa.getItems().contains(ropa.getTipoCierre())) {
                        FiltroCierreRopa.getItems().add(ropa.getTipoCierre());
                    }
                }
            }
            FiltroCierreRopa.setOnAction(e -> {
                aplicarFiltro();
            });
            FiltroCierreRopa.setValue("Todos");
            panelFiltros.add(new Label("Cierre:"), 0, fila);
            panelFiltros.add(FiltroCierreRopa, 1, fila++);

            if (FiltroTipo.getValue().equals("Camisa") ){

                // Combo Manga
                FiltroTipoManga.getItems().clear();

                for (Articulo articulo : todosLosArticulos) {
                    if (articulo instanceof Camisa) {
                        Camisa camisa = (Camisa) articulo;
                        if (!FiltroTipoManga.getItems().contains(camisa.getTipoManga())) {
                            FiltroTipoManga.getItems().add(camisa.getTipoManga());
                        }
                    }
                }
                FiltroTipoManga.setOnAction(e -> {
                    aplicarFiltro();
                });
                FiltroTipoManga.setValue("Todos");
                panelFiltros.add(new Label("Tipo de manga:"), 0, fila);
                panelFiltros.add(FiltroTipoManga, 1, fila++);

                //Checkbox Estampado
                FiltroEstampado.setOnAction(e -> {
                    aplicarFiltro();
                });
                panelFiltros.add(new Label("Estampada:"), 0, fila);
                panelFiltros.add(FiltroEstampado, 1, fila++);
            }
            if (FiltroTipo.getValue().equals("Pantalón") ){

                //Checkbox Bolsillos
                FiltroBolsillos.setOnAction(e -> {
                    aplicarFiltro();
                });
                panelFiltros.add(new Label("Con bolsillos:"), 0, fila);
                panelFiltros.add(FiltroBolsillos, 1, fila++);

                // Combo Tipo Pantalon
                FiltroTipoPantalon.getItems().clear();
                for (Articulo articulo : todosLosArticulos) {
                    if (articulo instanceof Pantalon) {
                        Pantalon pantalon = (Pantalon) articulo;
                        if (!FiltroTipoPantalon.getItems().contains(pantalon.getTipoPantalon())) {
                            FiltroTipoPantalon.getItems().add(pantalon.getTipoPantalon());
                        }
                    }
                }
                FiltroTipoPantalon.setOnAction(e -> {
                    aplicarFiltro();
                });
                FiltroTipoPantalon.setValue("Todos");
                panelFiltros.add(new Label("Tipo de pantalon:"), 0, fila);
                panelFiltros.add(FiltroTipoPantalon, 1, fila++);
            }






        }



    }


}
