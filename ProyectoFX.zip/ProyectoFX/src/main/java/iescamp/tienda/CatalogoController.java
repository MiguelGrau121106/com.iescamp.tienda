package iescamp.tienda;
import iescamp.tienda.modelo.Articulos.*;
import iescamp.tienda.modelo.dao.AccesorioDAO;
import iescamp.tienda.modelo.dao.ArticuloDAO;
import iescamp.tienda.modelo.dao.RopaDAO;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;

import java.util.List;
public class CatalogoController implements Refrescable {
    @FXML
    private VBox contenedorPrincipal;

    @FXML
    private VBox contenedorItems;

    @FXML
    private HBox contenedorFiltros;



    // ComboBoxes globales
    private ComboBox<String> FiltroTipo = new ComboBox<>();
    private ComboBox<String> FiltroColor = new ComboBox<>();
    private ComboBox<String> FiltroTalla = new ComboBox<>();
    private ComboBox<String> FiltroMaterial = new ComboBox<>();
    private ComboBox<String> FiltroMarca = new ComboBox<>();
    private ComboBox<String> FiltroEstilo = new ComboBox<>();
    private CheckBox FiltroPersonalizado = new CheckBox("Personalizado");
    private ComboBox<String> FiltroCierreBolso = new ComboBox<>();
    private ComboBox<String> FiltroCapacidad = new ComboBox<>();
    private ComboBox<String> FiltroTipoSuela = new ComboBox<>();
    private ComboBox<String> FiltroTallaZapato = new ComboBox<>();
    private ComboBox<String> FiltroCierreRopa = new ComboBox<>();
    private CheckBox FiltroImpermeable = new CheckBox("Impermeable");
    private ComboBox<String> FiltroTipoManga = new ComboBox<>();
    private CheckBox FiltroEstampado = new CheckBox("Estampado");
    private ComboBox<String> FiltroTipoPantalon = new ComboBox<>();
    private CheckBox FiltroBolsillos = new CheckBox("Bolsillos");



    @FXML
    private ScrollPane scrollPane;

    RopaDAO ropaDAO = new RopaDAO();
    AccesorioDAO accesorioDAO = new AccesorioDAO();
    ArticuloDAO articuloDAO = new ArticuloDAO();

    private GridPane grid = new GridPane();
    private List<Articulo> todosLosArticulos = articuloDAO.obtenerTodos();

    private static final int CURSOS_POR_PAGINA = 9;
    private int paginaActual = 0;

    @Override
    public void refrescar() {
        try {
            cargarContenido("Todos");


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void cargarContenido(String tipo) {
        // aplicar fondo color degradado azul-blanco
        contenedorPrincipal.setStyle("""
        -fx-background-color: linear-gradient(to bottom right, white, lightskyblue);
        """);
        contenedorPrincipal.setMinHeight(Screen.getPrimary().getBounds().getHeight());
        contenedorPrincipal.setAlignment(Pos.TOP_CENTER);
        contenedorFiltros.setAlignment(Pos.CENTER);
        // Combo Tipo
        FiltroTipo.getItems().addAll("Todos", "Camisa", "Pantalón", "Chaqueta",  "Zapatos", "Bolso");
        FiltroTipo.setValue("Todos");





        FiltroTipo.setOnAction(e -> {
            cargarFiltrosDisponibles();
            aplicarFiltro();
        });


        aplicarFiltro();
        cargarFiltrosDisponibles();

        scrollPane.setContent(contenedorPrincipal);

        scrollPane.vvalueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.doubleValue() == 1.0) {
                System.out.println("Scroll al final, cargando más productos...");
                cargarMasCursos();
            }
        });




    }






    private void aplicarFiltro() {
        paginaActual = 0;
        grid.getChildren().clear();
        System.out.println(todosLosArticulos.size());
        todosLosArticulos = articuloDAO.obtenerArticulosFiltrados(FiltroTipo.getValue(), FiltroColor.getValue(), FiltroTalla.getValue(), FiltroMaterial.getValue(), FiltroMarca.getValue() , FiltroEstilo.getValue(), FiltroPersonalizado.isSelected(), FiltroCierreBolso.getValue(), FiltroCapacidad.getValue(), FiltroTipoSuela.getValue(), FiltroTallaZapato.getValue(), FiltroCierreRopa.getValue(), FiltroImpermeable.isSelected(), FiltroTipoManga.getValue(), FiltroEstampado.isSelected(), FiltroTipoPantalon.getValue(), FiltroBolsillos.isSelected());
        System.out.println(todosLosArticulos.size());
        cargarMasCursos();
        contenedorItems.getChildren().setAll(grid);
    }

    private void cargarMasCursos() {
        int inicio = paginaActual * CURSOS_POR_PAGINA;
        int fin = Math.min(inicio + CURSOS_POR_PAGINA, todosLosArticulos.size());
        grid.setAlignment(Pos.CENTER);

        int columna = grid.getChildren().size() % 3;
        int fila = grid.getChildren().size() / 3;
        if (todosLosArticulos == null || todosLosArticulos.isEmpty()) {
            Label label = new Label("No hay artículos disponibles :(");
            label.setStyle("-fx-font-size: 30px;");

            grid.getChildren().add(label);


        }


        for (int i = inicio; i < fin; i++) {

            if (todosLosArticulos.get(i) instanceof Ropa) {

                Ropa ropa = (Ropa) todosLosArticulos.get(i);
                VBox tarjeta = new VBox(5);
                tarjeta.setPadding(new Insets(10));
                tarjeta.setAlignment(Pos.CENTER);
                Label nombre = new Label(ropa.getNombre());
                System.out.println(ropa.getImagen());
                java.net.URL imageUrl = getClass().getResource("/images/" + ropa.getImagen());
                if (imageUrl != null) {
                    Image imagen = new Image(imageUrl.toExternalForm());
                    ImageView imageView = new ImageView(imagen);
                    imageView.setFitWidth(600);
                    imageView.setFitHeight(600);
                    imageView.setPreserveRatio(true);
                    imageView.setOnMouseClicked( e -> {
                        SessionManager.getInstancia().setArticuloSeleccionado(ropa);
                        onProducto();
                    });
                    Label precio = new Label(String.valueOf(ropa.getPrecio()));
                    Button anyadirAlCarrito = new Button("Añadir al carrito");
                    anyadirAlCarrito.setOnAction(e -> SessionManager.getInstancia().addCarrito(ropa));
                    tarjeta.getChildren().addAll(imageView, nombre, precio, anyadirAlCarrito);
                    estilizarProducto(tarjeta);
                } else {
                    System.err.println("Image not found: /images/" + ropa.getImagen());
                }
                grid.add(tarjeta, columna, fila);
                columna++;
                if (columna == 3) {
                    columna = 0;
                    fila++;
                }
            } else if (todosLosArticulos.get(i) instanceof Accesorio) {
                Accesorio accesorio = (Accesorio) todosLosArticulos.get(i);
                VBox tarjeta = new VBox(5);
                tarjeta.setPadding(new Insets(10));
                tarjeta.setAlignment(Pos.CENTER);
                Label nombre = new Label(accesorio.getNombre());
                java.net.URL imageUrl = getClass().getResource("/images/" + accesorio.getImagen());
                if (imageUrl != null) {
                    Image imagen = new Image(imageUrl.toExternalForm());
                    ImageView imageView = new ImageView(imagen);
                    imageView.setFitWidth(600);
                    imageView.setFitHeight(600);
                    imageView.setPreserveRatio(true);
                    imageView.setOnMouseClicked( e -> {
                        SessionManager.getInstancia().setArticuloSeleccionado(accesorio);
                        onProducto();
                    });
                    Label precio = new Label(String.valueOf(accesorio.getPrecio()));
                    Button anyadirAlCarrito = new Button("Añadir al carrito");
                    anyadirAlCarrito.setOnAction(e -> SessionManager.getInstancia().addCarrito(accesorio));
                    tarjeta.getChildren().addAll(imageView, nombre, precio, anyadirAlCarrito);
                    estilizarProducto(tarjeta);
                } else {
                    System.err.println("Image not found: /images/tu_imagen.png");
                }
                grid.add(tarjeta, columna, fila);
                columna++;
                if (columna == 3) {
                    columna = 0;
                    fila++;
                }
            }

        }
        paginaActual++;
    }


    private void onProducto() {
        try {
            SessionManager.getInstancia().mostrar("producto.fxml");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public void cargarFiltrosDisponibles() {
        // resetear los valores de los filtros
        inicializarCombo(FiltroColor);
        inicializarCombo(FiltroMaterial);
        inicializarCombo(FiltroMarca);
        inicializarCombo(FiltroCierreBolso);
        inicializarCombo(FiltroCapacidad);
        inicializarCombo(FiltroTipoSuela);
        inicializarCombo(FiltroTallaZapato);
        inicializarCombo(FiltroTipoPantalon);
        inicializarCombo(FiltroEstilo);
        inicializarCombo(FiltroCierreRopa);
        inicializarCombo(FiltroTalla);
        inicializarCombo(FiltroTipoManga);
        FiltroImpermeable.setSelected(false);
        FiltroEstampado.setSelected(false);
        FiltroBolsillos.setSelected(false);
        FiltroPersonalizado.setSelected(false);


        // Limpiar los filtros existentes
        contenedorFiltros.getChildren().clear();
        // Crear un nuevo GridPane para los filtros
        GridPane panelFiltros = new GridPane();
        panelFiltros.setAlignment(Pos.CENTER);
        panelFiltros.setHgap(20);
        panelFiltros.setVgap(20);
        panelFiltros.setPadding(new Insets(10));
        int columna = 0;
        // Filtro tipo
        Label labelObjeto = new Label("Tipo:");
        labelObjeto.setStyle("""
        -fx-text-fill: black;
        -fx-font-size: 16px;
        -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
        -fx-alignment: center;
        -fx-padding: 6 12;
        """);
        panelFiltros.add(labelObjeto, columna, 0);
        estilizarComboBox(FiltroTipo);
        panelFiltros.add(FiltroTipo, columna++, 1);

        // Inicializar con "Todos"


        contenedorFiltros.getChildren().add(panelFiltros);







        for (Articulo articulo : todosLosArticulos) {
            if (!FiltroColor.getItems().contains(articulo.getColor())) {
                FiltroColor.getItems().add(articulo.getColor());
            }

            String material = articulo.getMaterial().getDenominacion();
            if (!FiltroMaterial.getItems().contains(material)) {
                FiltroMaterial.getItems().add(material);
            }

            if (!FiltroMarca.getItems().contains(articulo.getMarca())) {
                FiltroMarca.getItems().add(articulo.getMarca());
            }
        }

        configurarCombo(FiltroColor, panelFiltros, "Color:", columna++);
        configurarCombo(FiltroMaterial, panelFiltros, "Material:", columna++);
        configurarCombo(FiltroMarca, panelFiltros, "Marca:", columna++);

        String tipoSeleccionado = FiltroTipo.getValue();

        if (tipoSeleccionado.equals("Camisa") || tipoSeleccionado.equals("Pantalón") || tipoSeleccionado.equals("Chaqueta")) {
            inicializarCombo(FiltroTalla);
            inicializarCombo(FiltroCierreRopa);

            for (Articulo articulo : todosLosArticulos) {
                if (articulo instanceof Ropa ropa) {
                    if (!FiltroTalla.getItems().contains(ropa.getTalla())) {
                        FiltroTalla.getItems().add(ropa.getTalla());
                    }
                    if (!FiltroCierreRopa.getItems().contains(ropa.getTipoCierre())) {
                        FiltroCierreRopa.getItems().add(ropa.getTipoCierre());
                    }
                }
            }

            configurarCombo(FiltroTalla, panelFiltros, "Talla:", columna++);
            configurarCombo(FiltroCierreRopa, panelFiltros, "Cierre:", columna++);

            if (tipoSeleccionado.equals("Camisa")) {
                inicializarCombo(FiltroTipoManga);
                for (Articulo articulo : todosLosArticulos) {
                    if (articulo instanceof Camisa camisa) {
                        if (!FiltroTipoManga.getItems().contains(camisa.getTipoManga())) {
                            FiltroTipoManga.getItems().add(camisa.getTipoManga());
                        }
                    }
                }
                configurarCombo(FiltroTipoManga, panelFiltros, "Tipo de manga:", columna++);
                FiltroEstampado.setOnAction(e -> aplicarFiltro());
                estilizarCheckBox(FiltroEstampado);
                panelFiltros.add(FiltroEstampado,  0, 2);
            }

            if (tipoSeleccionado.equals("Pantalón")) {
                FiltroBolsillos.setOnAction(e -> aplicarFiltro());
                estilizarCheckBox(FiltroBolsillos);
                panelFiltros.add(FiltroBolsillos, 0, 2);

                for (Articulo articulo : todosLosArticulos) {
                    if (articulo instanceof Pantalon pantalon) {
                        if (!FiltroTipoPantalon.getItems().contains(pantalon.getTipoPantalon())) {
                            FiltroTipoPantalon.getItems().add(pantalon.getTipoPantalon());
                        }
                    }
                }
                configurarCombo(FiltroTipoPantalon, panelFiltros, "Tipo de pantalón:", columna++);
            }

            if (tipoSeleccionado.equals("Chaqueta")) {
                FiltroImpermeable.setOnAction(e -> aplicarFiltro());
                estilizarCheckBox(FiltroImpermeable);
                panelFiltros.add(FiltroImpermeable, 0, 2);
            }

        } else if (tipoSeleccionado.equals("Zapatos") || tipoSeleccionado.equals("Bolso")) {

            inicializarCombo(FiltroEstilo);
            for (Articulo articulo : todosLosArticulos) {
                if (articulo instanceof Zapatos zapatos) {
                    if (!FiltroEstilo.getItems().contains(zapatos.getEstilo())) {
                        FiltroEstilo.getItems().add(zapatos.getEstilo());
                    }
                }
            }
            configurarCombo(FiltroEstilo, panelFiltros, "Estilo:", columna++);
            FiltroPersonalizado.setOnAction(e -> aplicarFiltro());
            estilizarCheckBox(FiltroPersonalizado);
            panelFiltros.add(FiltroPersonalizado,  0, 2);

            if (tipoSeleccionado.equals("Zapatos")) {
                for (Articulo articulo : todosLosArticulos) {
                    if (articulo instanceof Zapatos zapatos) {
                        String talla = String.valueOf(zapatos.getTallaZapatos());
                        if (!FiltroTallaZapato.getItems().contains(talla)) {
                            FiltroTallaZapato.getItems().add(talla);
                        }
                        if (!FiltroTipoSuela.getItems().contains(zapatos.getTipoSuela())) {
                            FiltroTipoSuela.getItems().add(zapatos.getTipoSuela());
                        }
                    }
                }
                configurarCombo(FiltroTallaZapato, panelFiltros, "Talla:", columna++);
                configurarCombo(FiltroTipoSuela, panelFiltros, "Tipo de suela:", columna++);
            } else if (tipoSeleccionado.equals("Bolso")) {
                for (Articulo articulo : todosLosArticulos) {
                    if (articulo instanceof Bolso bolso) {
                        String capacidad = String.valueOf(bolso.getCapacidad());
                        if (!FiltroCapacidad.getItems().contains(capacidad)) {
                            FiltroCapacidad.getItems().add(capacidad);
                        }
                        if (!FiltroCierreBolso.getItems().contains(bolso.getTipoCierre())) {
                            FiltroCierreBolso.getItems().add(bolso.getTipoCierre());
                        }
                    }
                }
                configurarCombo(FiltroCapacidad, panelFiltros, "Capacidad:", columna++);
                configurarCombo(FiltroCierreBolso, panelFiltros, "Cierre:", columna++);
            }
        }
    }
    private void inicializarCombo(ComboBox<String> combo) {
        combo.getItems().clear();
        combo.getItems().add("Todos");
        combo.setValue("Todos");
    }

    private void configurarCombo(ComboBox<String> combo, GridPane panel, String label, int columna) {
        combo.setOnAction(e -> aplicarFiltro());
        combo.setValue("Todos");
        estilizarComboBox(combo);
        Label labelObjeto = new Label(label);
        labelObjeto.setAlignment(Pos.CENTER);
        labelObjeto.setStyle("""
        -fx-text-fill: black;
        -fx-font-size: 16px;
        -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
        -fx-alignment: center;
        -fx-padding: 6 12;
        """);
        panel.add(labelObjeto, columna, 0);
        panel.add(combo, columna, 1);
        panel.setAlignment(Pos.CENTER);
    }

    private void estilizarComboBox(ComboBox<?> combo) {

        combo.setStyle("""
        -fx-background-color: white;
        -fx-border-color: black;
        -fx-border-width: 1;
        -fx-border-radius: 30;
        -fx-background-radius: 30;
        -fx-padding: 6 12;
        -fx-font-size: 14px;
        -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
        -fx-text-fill: black;
        -fx-cursor: hand;
    """);
        combo.setOnMouseEntered(e -> {
            combo.setStyle("""
            -fx-background-color: lightgray;
            -fx-border-color: black;
            -fx-border-width: 1;
            -fx-border-radius: 30;
            -fx-background-radius: 30;
            -fx-padding: 6 12;
            -fx-font-size: 14px;
            -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            -fx-text-fill: black;
            -fx-cursor: hand;
        """);
        });
        combo.setOnMouseExited(e -> {
            combo.setStyle("""
            -fx-background-color: white;
            -fx-border-color: black;
            -fx-border-width: 1;
            -fx-border-radius: 30;
            -fx-background-radius: 30;
            -fx-padding: 6 12;
            -fx-font-size: 14px;
            -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            -fx-text-fill: black;
            -fx-cursor: hand;
        """);
        });
    }

    private void estilizarProducto(VBox tarjeta) {
        tarjeta.setStyle("""
        -fx-padding: 10;
        -fx-spacing: 8;
    """);

        for (Node nodo : tarjeta.getChildren()) {
            if (nodo instanceof Label label) {
                label.setStyle("""
                -fx-text-fill: black;
                -fx-font-size: 16px;
                -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
                -fx-alignment: center;
            """);
            } else if (nodo instanceof Button boton) {
                boton.setStyle("""
                -fx-background-color: black;
                -fx-border-color: white;
                -fx-text-fill: white;
                -fx-font-size: 14px;
                -fx-padding: 6 12;
                -fx-cursor: hand;
                -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            """);

                boton.setOnMouseEntered(e -> boton.setStyle("""
                -fx-background-color: white;
                -fx-text-fill: black;
                -fx-border-color: black;
                -fx-font-size: 14px;
                -fx-padding: 6 12;
                -fx-cursor: hand;
                -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            """));

                boton.setOnMouseExited(e -> boton.setStyle("""
                -fx-background-color: black;
                -fx-border-color: white;
                -fx-text-fill: white;
                -fx-font-size: 14px;
                -fx-padding: 6 12;
                -fx-cursor: hand;
                -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            """));
            }
        }
    }

    public void estilizarCheckBox(CheckBox checkBox) {
        checkBox.setStyle("""
        -fx-text-fill: black;
        -fx-font-size: 16px;
        -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
        -fx-alignment: center;
        -fx-padding: 6 12;
    """);
        checkBox.setOnMouseEntered(e -> {
            checkBox.setStyle("""
            -fx-text-fill: lightgray;
            -fx-font-size: 16px;
            -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            -fx-alignment: center;
            -fx-padding: 6 12;
        """);
        });
        checkBox.setOnMouseExited(e -> {
            checkBox.setStyle("""
            -fx-text-fill: black;
            -fx-font-size: 16px;
            -fx-font-family: "Helvetica Neue", "Arial", sans-serif;
            -fx-alignment: center;
            -fx-padding: 6 12;
        """);
        });
    }

}













