package iescamp.tienda;

public class EditarEmpleado {
}
