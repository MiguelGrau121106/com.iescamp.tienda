package iescamp.tienda;

import iescamp.tienda.modelo.Articulos.Articulo;
import iescamp.tienda.modelo.Articulos.Ropa;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.IOException;

public class ProductoController implements Refrescable {
    @FXML
    public Label lbNombre;
    @FXML
    public Label lbPrecio;
    @FXML
    public Button btAnyadirCarrito;
    @FXML
    public Text lbDescripcion;
    @FXML
    public VBox vboxComoSoy;
    @FXML
    public ImageView productImageView;

    @Override
    public void refrescar() {
        cargarContenido();
    }

    private void cargarContenido() {
        Articulo articulo = SessionManager.getInstancia().getArticuloSeleccionado();

        if (articulo != null) {
            lbNombre.setText(articulo.getNombre());
            lbPrecio.setText(String.valueOf(articulo.getPrecio()) + " €");
            lbDescripcion.setText(articulo.getDescripcion());
            java.net.URL imageUrl = getClass().getResource("/images/" + articulo.getImagen());
            Image imagen = new Image(imageUrl.toExternalForm());

            productImageView.setImage(imagen);
            SessionManager.getInstancia().setArticuloSeleccionado(null);


                vboxComoSoy.getChildren().clear();

                vboxComoSoy.getChildren().add(new Label("Color: " + articulo.getColor()));
                vboxComoSoy.getChildren().add(new Label("Material: " + articulo.getMaterial().getDenominacion()));
                if (articulo instanceof Ropa) {
                    Ropa ropa = (Ropa) articulo;
                    vboxComoSoy.getChildren().add(new Label("Talla: " + ropa.getTalla()));
                }





        } else {
            System.out.println("No hay articulo seleccionado");
        }


    }

    @FXML
    public void onCatalogo(){
        try {
            SessionManager.getInstancia().volverAtras();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
