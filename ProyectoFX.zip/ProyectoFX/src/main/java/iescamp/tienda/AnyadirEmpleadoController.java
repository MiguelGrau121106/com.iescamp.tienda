package iescamp.tienda;

import iescamp.tienda.modelo.Usuarios.Cliente;
import iescamp.tienda.modelo.Usuarios.Departamento;
import iescamp.tienda.modelo.Usuarios.Empleado;
import iescamp.tienda.modelo.Usuarios.MetodoPago;
import iescamp.tienda.modelo.dao.ClienteDAO;
import iescamp.tienda.modelo.dao.DepartamentoDAO;
import iescamp.tienda.modelo.dao.EmpleadoDAO;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.time.LocalDate;
import java.util.regex.Pattern;

public class AnyadirEmpleadoController {

    @FXML
    private TextField txtNombre, txtApellidos, txtCorreo, txtContrasenya, txtTelefono, txtDireccion, txtDni, txtSalario, txtDepartamento;

    @FXML
    private DatePicker DpNac;

    @FXML
    private CheckBox CheckBoxPriv;
;


    @FXML
    public void onPanelAdmin(){
        try {
            SessionManager.getInstancia().mostrar("panel_admin.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void guardar(){


        String nombre = txtNombre.getText();
        String apellidos = txtApellidos.getText();
        String correo = txtCorreo.getText();
        String contrasenya = txtContrasenya.getText();
        String telefono = txtTelefono.getText();
        String direccion = txtDireccion.getText();
        String dni = txtDni.getText();
        String salario = txtSalario.getText();
        String departamento = txtDepartamento.getText();
        LocalDate fechaNacimiento = DpNac.getValue();
        String email = txtCorreo.getText();
        String contrasena = txtContrasenya.getText();
        boolean privilegios = CheckBoxPriv.isSelected();

        if (nombre.isEmpty() || apellidos.isEmpty() || email.isEmpty() || dni.isEmpty() || fechaNacimiento == null
                || direccion.isEmpty() || telefono.isEmpty() || contrasena.isEmpty()) {
            mostrarAlerta(Alert.AlertType.ERROR, "Campos incompletos", "Por favor, complete todos los campos obligatorios.");
            return;
        }

        if (!esEmailValido(email)) {
            mostrarAlerta(Alert.AlertType.ERROR, "Email inválido", "El formato del correo electrónico es incorrecto.");
            return;
        }



        if (!esDNICorrecto(dni)) {
            mostrarAlerta(Alert.AlertType.ERROR, "DNI inválido", "El DNI debe tener 8 dígitos y una letra.");
            return;
        }

        // Aquí puedes agregar la lógica para guardar el empleado en la base de datos

        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        DepartamentoDAO departamentoDAO = new DepartamentoDAO();

        Departamento departamentoObj = departamentoDAO.obtenerPorNombre(departamento);

        // Verificar si el departamento existe
        if (departamentoObj == null) {
            mostrarAlerta(Alert.AlertType.ERROR, "Departamento no encontrado", "El departamento especificado no existe, creandolo como nuevo departamento." );
            // Crear un nuevo departamento
            departamentoDAO.insertar(new Departamento(0,departamento));
            departamentoObj = departamentoDAO.obtenerPorNombre(departamento);
        }


        // Crear el objeto Empleado
        Empleado empleado = new Empleado( dni, nombre, apellidos, direccion, email, telefono, fechaNacimiento, contrasena, true,privilegios,  departamentoObj);
        empleadoDAO.insertar(empleado);
        // Mostrar mensaje de éxito





        mostrarAlerta(Alert.AlertType.INFORMATION, "Empleado añadido", "Empleado añadido correctamente");



        // Limpiar campos tras registro
        limpiarCampos();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtApellidos.clear();
        txtCorreo.clear();
        txtContrasenya.clear();
        txtTelefono.clear();
        txtDireccion.clear();
        txtDni.clear();
        DpNac.setValue(null);
        CheckBoxPriv.setSelected(false);
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private boolean esEmailValido(String email) {
        String regex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        return Pattern.matches(regex, email);
    }

    private boolean esDNICorrecto(String dni) {
        String regex = "^[0-9]{8}[A-Za-z]$";
        return Pattern.matches(regex, dni);
    }



}
