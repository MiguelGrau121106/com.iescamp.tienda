package iescamp.tienda.modelo.dao;

import iescamp.tienda.SessionManager;
import iescamp.tienda.modelo.Articulos.Articulo;
import iescamp.tienda.modelo.Articulos.Catalogo;
import iescamp.tienda.modelo.Articulos.Material;
import iescamp.tienda.modelo.Articulos.Ropa;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase DAO para manejar operaciones CRUD sobre la tabla 'articulo' en la base de datos.
 */
public class ArticuloDAO implements GenericDAO<Articulo, Integer> {

    @Override
    public void insertar(Articulo articulo) {
        // Inserta un nuevo artículo en la base de datos
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "INSERT INTO articulo (cod_art, nombre, precio, marca, descripcion, activo, imagen, color, material) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, articulo.getCod_art());
            pstmt.setString(2, articulo.getNombre());
            pstmt.setDouble(3, articulo.getPrecio());
            pstmt.setString(4, articulo.getMarca());
            pstmt.setString(5, articulo.getDescripcion());
            pstmt.setBoolean(6, articulo.isActivo());
            pstmt.setString(7, articulo.getImagen());
            pstmt.setString(8, articulo.getColor());
            pstmt.setInt(9, articulo.getMaterial().getCodigo());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Articulo obtenerPorId(Integer cod_art) {
        // Busca un artículo por su ID
        try  (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM articulo WHERE cod_art = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, cod_art);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                DBUtil.closeConnection(conn);
                // Construye el objeto a partir del resultado
                return construirDesdeResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Articulo> obtenerTodos() {
        // Obtiene todos los artículos de la tabla
        List<Articulo> articulo = new ArrayList<>();
        String sql = "SELECT * FROM articulo,ropa,accesorio WHERE articulo.cod_art=ropa.cod_art OR articulo.cod_art=accesorio.cod_art";

        Statement stmt = null;
        try (Connection conn = DBUtil.getConnection()) {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    articulo.add(construirDesdeResultSet(rs, conn));
                }
                DBUtil.closeConnection(conn);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return articulo;
    }

    @Override
    public void actualizar(Articulo articulo) {
        // Actualiza un artículo existente
        String sql = "UPDATE articulo SET nombre = ?, precio = ?, marca = ?, descripcion = ?, activo = ?, imagen = ?, color = ?, material = ? WHERE cod_art = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, articulo.getNombre());
            stmt.setDouble(2, articulo.getPrecio());
            stmt.setString(3, articulo.getMarca());
            stmt.setString(4, articulo.getDescripcion());
            stmt.setBoolean(5, articulo.isActivo());
            stmt.setString(6, articulo.getImagen());
            stmt.setString(7, articulo.getColor());
            stmt.setInt(8, articulo.getMaterial().getCodigo());
            stmt.setInt(9, articulo.getCod_art());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Integer cod_art) {
        // Elimina un artículo por su ID
        String sql = "DELETE FROM articulo WHERE cod_art = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cod_art);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método auxiliar que obtiene un objeto Material desde su código (clave primaria).
     */
    private Material obtenerMaterialPorCodigo(int codigo) throws SQLException {
        String sql = "SELECT * FROM material WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, codigo);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Material(rs.getInt("codigo"), rs.getString("denominacion"));
            }
        }
        return null;
    }

    @Override
    public Articulo construirDesdeResultSet(ResultSet rs) throws SQLException {

        if (rs.getString("tipo_ropa") != null) {
            RopaDAO ropaDAO = new RopaDAO();
            return ropaDAO.construirDesdeResultSet(rs);
        }
        if (rs.getString("tipo_accesorio") != null) {
            AccesorioDAO accesorioDAO = new AccesorioDAO();
            return accesorioDAO.construirDesdeResultSet(rs);
        }


        return null;
    }

    public Articulo construirDesdeResultSet(ResultSet rs, Connection conn) throws SQLException {

        if (rs.getString("tipo_ropa") != null) {
            RopaDAO ropaDAO = new RopaDAO();
            return ropaDAO.construirDesdeResultSet(rs, conn);
        }
        if (rs.getString("tipo_accesorio") != null) {
            AccesorioDAO accesorioDAO = new AccesorioDAO();
            return accesorioDAO.construirDesdeResultSet(rs, conn);
        }


        return null;
    }


    public List<Articulo> obtenerArticulosFiltrados(String tipo, String color, String talla, String material, String estilo,
                                                    Boolean personalizado, String tipoCierreBolso, String capacidad, String tipoSuela,
                                                    String tallaZapato, String tipoCierreRopa, Boolean impermeable, String tipoManga,
                                                    Boolean estampada, String tipoPantalon, Boolean tieneBolsillos) {
        Connection conn = null;
        try {
            conn = DBUtil.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        List<Articulo> articulos = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT * FROM articulo " +
                        "LEFT JOIN ropa ON articulo.cod_art = ropa.cod_art " +
                        "LEFT JOIN accesorio ON articulo.cod_art = accesorio.cod_art " +
                        "WHERE articulo.activo = 1");

        List<Object> parametros = new ArrayList<>();

        if (tipo != null && !tipo.equals("Todos")) {
            sql.append(" AND (tipo_ropa = ? OR tipo_accesorio = ?)");
            parametros.add(tipo);
            parametros.add(tipo);
        }
        if (color != null && !color.equals("Todos")) {
            sql.append(" AND articulo.color = ?");
            parametros.add(color);
        }
        if (talla != null && !talla.equals("Todos")) {
            sql.append(" AND ropa.talla_ropa = ?");
            parametros.add(talla);
        }
        if (material != null && !material.equals("Todos")) {
            Material materialObj = obtenerMaterialPorNombre(material, conn);

            sql.append(" AND articulo.material = ?");
            parametros.add(materialObj.getCodigo());
        }
        if (estilo != null && !estilo.equals("Todos")) {
            sql.append(" AND accesorio.estilo = ?");
            parametros.add(estilo);
        }
        if (personalizado != null && personalizado) {
            sql.append(" AND accesorio.personalizado = 1");

        }
        if (tipoCierreBolso != null && !tipoCierreBolso.equals("Todos")) {
            sql.append(" AND accesorio.tipo_cierre_bolso = ?");
            parametros.add(tipoCierreBolso);
        }
        if (capacidad != null && !capacidad.equals("Todos")) {
            sql.append(" AND accesorio.capacidad = ?");
            parametros.add(capacidad);
        }
        if (tipoSuela != null && !tipoSuela.equals("Todos")) {
            sql.append(" AND accesorio.tipo_suela = ?");
            parametros.add(tipoSuela);
        }
        if (tallaZapato != null && !tallaZapato.equals("Todos")) {
            sql.append(" AND accesorio.talla_zapato = ?");
            parametros.add(tallaZapato);
        }
        if (tipoCierreRopa != null && !tipoCierreRopa.equals("Todos")) {
            sql.append(" AND ropa.tipo_cierre = ?");
            parametros.add(tipoCierreRopa);
        }
        if (impermeable) {
            sql.append(" AND ropa.impermeable = 1");

        }

        if (tipoManga != null && !tipoManga.equals("Todos")) {
            sql.append(" AND ropa.tipo_manga = ?");
            parametros.add(tipoManga);
        }
        if (estampada != null && estampada) {
            sql.append(" AND ropa.estampada = 1");

        }
        if (tipoPantalon != null && !tipoPantalon.equals("Todos")) {
            sql.append(" AND ropa.tipo_pantalón = ?");
            parametros.add(tipoPantalon);
        }
        if (tieneBolsillos != null && tieneBolsillos) {
            sql.append(" AND ropa.tiene_bolsillos = 1");

        }

        try {
            PreparedStatement pstmt = conn.prepareStatement(sql.toString());

            for (int i = 0; i < parametros.size(); i++) {
                pstmt.setObject(i + 1, parametros.get(i));
            }

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Articulo articulo = construirDesdeResultSet(rs, conn);
                if (articulo != null) {
                    articulos.add(articulo);
                }
            }


            return articulos;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

        private Material obtenerMaterialPorNombre(String material, Connection conn) {
        try  {
            if (conn == null) {
                conn = DBUtil.getConnection();
            }

            String sql = "SELECT * FROM material WHERE denominacion = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, material);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Material(rs.getInt("codigo"), rs.getString("denominacion"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}



