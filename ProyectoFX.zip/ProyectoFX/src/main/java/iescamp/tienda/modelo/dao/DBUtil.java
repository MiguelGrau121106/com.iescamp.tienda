package iescamp.tienda.modelo.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase de utilidad para gestionar conexiones a la base de datos.
 */
public class DBUtil {

    // URL de conexión a la base de datos MySQL que incluye el nombre de la base de datos.
    private static final String URL = "jdbc:mysql://localhost:3306/tienda_ropa?useSSL=false&serverTimezone=UTC"
            ;

    // Usuario y contraseña para acceder a la base de datos
    private static final String USUARIO = "root";
    private static final String CONTRASENA = "MySQL24-25";

    /**
     * Devuelve una nueva conexión a la base de datos.
     * @return conexión abierta
     * @throws SQLException si ocurre un error al conectar
     */
    public static Connection getConnection() throws SQLException {
        int reintentos = 3;
        int esperaMs = 1000; // 1 segundo

        while (reintentos > 0) {
            try {
                return DriverManager.getConnection(URL, USUARIO, CONTRASENA);
            } catch (SQLException e) {
                System.err.println("Error al conectar a la base de datos: " + e.getMessage());
                reintentos--;
                if (reintentos == 0) {
                    // Si ya no quedan reintentos, relanza la excepción para que se maneje adecuadamente.
                    throw e;
                }
                try {
                    Thread.sleep(esperaMs);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new SQLException("Interrumpido mientras esperaba para reconectar.", ie);
                }
            }
        }
        // Este punto nunca se alcanza debido al relanzamiento, pero es necesario para compilar.
        throw new SQLException("No se pudo conectar tras varios intentos.");

    }

    /**
     * Cierra la conexión si no es null.
     * @param connection la conexión a cerrar
     */
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexión cerrada correctamente.");
            } catch (SQLException e) {
                e.printStackTrace(); // Imprime el error si no se puede cerrar
            }
        }
    }
}
