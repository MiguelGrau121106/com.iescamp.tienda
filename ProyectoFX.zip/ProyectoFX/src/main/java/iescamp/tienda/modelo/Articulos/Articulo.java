package iescamp.tienda.modelo.Articulos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import java.io.Serializable;
import java.util.Objects;

/**
 * Clase abstracta que representa un artículo genérico de la tienda.
 * Puede ser extendida por subclases como Ropa o Accesorio.
 */
@JsonTypeInfo(
        use = JsonTypeInfo.Id.CLASS,
        include = JsonTypeInfo.As.PROPERTY,
        property = "@class"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Accesorio.class, name = "accesorio"),
        @JsonSubTypes.Type(value = Ropa.class, name = "ropa")
})
public abstract class Articulo implements Serializable {
    private static final long serialVersionUID = 1L;

    private Material material;
    private int cod_art;
    private boolean activo;
    private String imagen;
    private String nombre;
    private double precio;
    private String marca;
    private String descripcion;
    private String color;

    // ================= Getters y Setters =================

    /**
     * @return color del artículo
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color color a establecer para el artículo
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * @return material del artículo
     */
    public Material getMaterial() {
        return material;
    }

    /**
     * @param material material a establecer
     */
    public void setMaterial(Material material) {
        this.material = material;
    }

    /**
     * @return código del artículo
     */
    public int getCod_art() {
        return cod_art;
    }

    /**
     * @param cod_art código único del artículo
     */
    public void setCod_art(int cod_art) {
        this.cod_art = cod_art;
    }

    /**
     * @return true si el artículo está activo, false si está desactivado
     */
    public boolean isActivo() {
        return activo;
    }

    /**
     * @param activo indica si el artículo está activo o no
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    /**
     * @return nombre del archivo de imagen del artículo
     */
    public String getImagen() {
        return imagen;
    }

    /**
     * @param imagen nombre del archivo de imagen
     */
    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    /**
     * @return nombre del artículo
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre nombre a establecer para el artículo
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return precio del artículo
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio precio a establecer
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * @return marca del artículo
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca marca a establecer para el artículo
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return descripción del artículo
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion descripción a establecer para el artículo
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    // ================= equals, hashCode =================

    /**
     * Compara este artículo con otro objeto.
     * @param object objeto con el que se compara
     * @return true si todos los atributos son iguales
     */
    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        Articulo articulo = (Articulo) object;
        return cod_art == articulo.cod_art &&
                activo == articulo.activo &&
                Double.compare(precio, articulo.precio) == 0 &&
                Objects.equals(material, articulo.material) &&
                Objects.equals(imagen, articulo.imagen) &&
                Objects.equals(nombre, articulo.nombre) &&
                Objects.equals(marca, articulo.marca) &&
                Objects.equals(descripcion, articulo.descripcion);
    }

    /**
     * Genera un hash basado en los atributos del artículo.
     * @return código hash del artículo
     */
    @Override
    public int hashCode() {
        return Objects.hash(material, cod_art, activo, imagen, nombre, precio, marca, descripcion);
    }

    // ================= Constructor =================

    /**
     * Constructor completo de la clase.
     * @param material material del artículo
     * @param cod_art código único del artículo
     * @param activo indica si el artículo está activo
     * @param color color del artículo
     * @param imagen archivo de imagen
     * @param nombre nombre del artículo
     * @param precio precio del artículo
     * @param marca marca del artículo
     * @param descripcion descripción del artículo
     */
    @JsonCreator
    public Articulo(
            @JsonProperty("material") Material material,
            @JsonProperty("cod_art") int cod_art,
            @JsonProperty("activo") boolean activo,
            @JsonProperty("color") String color,
            @JsonProperty("imagen") String imagen,
            @JsonProperty("nombre") String nombre,
            @JsonProperty("precio") double precio,
            @JsonProperty("marca") String marca,
            @JsonProperty("descripcion") String descripcion) {
        this.material = material;
        this.cod_art = cod_art;
        this.activo = activo;
        this.color = color;
        this.imagen = imagen;
        this.nombre = nombre;
        this.precio = precio;
        this.marca = marca;
        this.descripcion = descripcion;
    }

    /**
     * @return representación del artículo como cadena de texto
     */
    @Override
    public String toString() {
        return "Articulo{" +
                "material=" + material +
                ", cod_art=" + cod_art +
                ", activo=" + activo +
                ", imagen='" + imagen + '\'' +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", marca='" + marca + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", color='" + color + '\'' +
                '}';
    }

    /**
     * Devuelve el tipo específico de artículo (ropa o accesorio).
     * @return tipo concreto como enum TipoRopa o TipoAccesorio, o null si no es ninguno
     */
    public Object getTipo() {
        if (this instanceof Accesorio) {
            return TipoAccesorio.valueOf(((Accesorio) this).getTipoAccesorio().toString());
        } else if (this instanceof Ropa) {
            return TipoRopa.valueOf(((Ropa) this).getTipoRopa().toString());
        }
        return null;
    }
}
