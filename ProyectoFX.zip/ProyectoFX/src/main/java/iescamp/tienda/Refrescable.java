package iescamp.tienda;

public interface Refrescable {
    void refrescar();
}
