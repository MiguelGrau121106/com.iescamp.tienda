package iescamp.tienda;

import javafx.scene.input.MouseEvent;

import java.io.IOException;

public class PanelAdminController {
    public void onEditarEmpleado(MouseEvent mouseEvent) {

    }

    public void onListarUsuarios(MouseEvent mouseEvent) {
    }

    public void onAñadirEmpleado(MouseEvent mouseEvent) {
        try{
            SessionManager.getInstancia().mostrar("añadir_empleado.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
