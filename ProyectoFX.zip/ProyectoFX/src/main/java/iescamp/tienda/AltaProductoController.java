package iescamp.tienda;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

public class AltaProductoController {


    @FXML
    private GridPane grid;

    private TextField tfTipo = new TextField();
    private TextField tfColor = new TextField();
    private TextField tfTalla = new TextField();
    private TextField tfMaterial= new TextField();
    private TextField tfMarca = new TextField();
    private TextField tfEstilo = new TextField();
    private CheckBox cbPersonalizado = new CheckBox("Personalizado");
    private TextField tfCierreBolso = new TextField();
    private TextField tfCapacidad = new TextField();
    private TextField tfTipoSuela = new TextField();
    private TextField tfTallaZapato = new TextField();
    private TextField tfCierreRopa = new TextField();
    private CheckBox cbImpermeable = new CheckBox("Impermeable");
    private TextField tfTipoManga = new TextField();
    private CheckBox cbEstampado = new CheckBox("Estampado");
    private TextField tfTipoPantalon = new TextField();
    private CheckBox cbBolsillos = new CheckBox("Bolsillos");
    private int x, y;

    @FXML
    public void initialize() {
        try {
            cargarContenido();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cargarContenido() {


        grid.getChildren().clear(); // Limpiar el GridPane antes de cargar nuevo contenido
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setStyle("-fx-padding: 10; -fx-background-color: #f0f0f0;");
        HBox tarjeta = new HBox();
        tarjeta.setAlignment(Pos.CENTER);
        tarjeta.setSpacing(10);
        Label label = new Label("Selecciona el tipo de producto:");
        label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        label.setAlignment(Pos.CENTER);
        tarjeta.getChildren().add(label);
        ComboBox<String> comboBox = new ComboBox<>();
        comboBox.getItems().addAll("Camisa", "Pantalon", "Chaqueta","Zapatos", "Bolso" );
        tarjeta.getChildren().add(comboBox);
        grid.add(tarjeta, 0, 0);



    }


}
