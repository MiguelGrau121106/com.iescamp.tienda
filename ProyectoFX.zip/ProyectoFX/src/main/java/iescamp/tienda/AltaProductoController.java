package iescamp.tienda;

import iescamp.tienda.modelo.Articulos.*;
import iescamp.tienda.modelo.dao.MaterialDAO;
import iescamp.tienda.modelo.dao.RopaDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class AltaProductoController {

    @FXML
    private Button btnGuardar;

    @FXML
    private GridPane grid;
    private ComboBox<String> cobxTipo = new ComboBox<>();
    private TextField tfTipo = new TextField();
    private TextField tfDescripcion = new TextField();
    private TextField tfPrecio = new TextField();
    private TextField tfNombre = new TextField();
    private TextField tfColor = new TextField();
    private TextField tfTalla = new TextField();
    private TextField tfMaterial= new TextField();
    private TextField tfMarca = new TextField();
    private TextField tfEstilo = new TextField();
    private CheckBox cbPersonalizado = new CheckBox("Personalizado");
    private TextField tfCierreBolso = new TextField();
    private TextField tfCapacidad = new TextField();
    private TextField tfTipoSuela = new TextField();
    private TextField tfTallaZapato = new TextField();
    private TextField tfCierreRopa = new TextField();
    private CheckBox cbImpermeable = new CheckBox("Impermeable");
    private TextField tfTipoManga = new TextField();
    private CheckBox cbEstampado = new CheckBox("Estampado");
    private TextField tfTipoPantalon = new TextField();
    private CheckBox cbBolsillos = new CheckBox("Bolsillos");
    private int x, y;
    private File selectedFileG;
    private Path targetPathG;


    @FXML
    public void initialize() {
        try {
            cargarContenido();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cargarContenido() {


        grid.getChildren().clear(); // Limpiar el GridPane antes de cargar nuevo contenido
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setStyle("-fx-padding: 10; -fx-background-color: #f0f0f0;");
        crearTarjetaTipo("");


    }

    public void crearTarjetaTipo(String tipo) {
        HBox tarjeta = new HBox();
        tarjeta.setAlignment(Pos.CENTER);
        tarjeta.setSpacing(10);
        Label label = new Label("Selecciona el tipo de producto:");
        label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        label.setAlignment(Pos.CENTER);
        tarjeta.getChildren().add(label);

        cobxTipo.setValue(tipo);

        cobxTipo.getItems().addAll("Camisa", "Pantalon", "Chaqueta","Zapatos", "Bolso" );
        cobxTipo.setOnAction(event -> {
            String tipoSelecc = cobxTipo.getValue();
            grid.getChildren().clear(); // Limpiar el GridPane antes de cargar nuevo contenido
            crearTarjetaPorTipo(tipoSelecc);
        });
        tarjeta.getChildren().add(cobxTipo);
        grid.add(tarjeta, 0, 0);

        btnGuardar.setOnAction(event -> {
            guardar();
        });

    }



    public void crearTarjetaPorTipo(String tipo) {
        int fila = 1;
        crearTarjetaTipo(tipo);
        crearTarjeta("Nombre:", tfNombre, fila++);
        crearTarjeta("Color:", tfColor, fila++);
        crearTarjeta("Material:", tfMaterial, fila++);
        crearTarjeta("Marca:", tfMarca, fila++);
        crearTarjeta("Descripción:", tfDescripcion, fila++);
        crearTarjeta("Precio:", tfPrecio, fila++);

        if (tipo.equals("Camisa")) {
            crearTarjeta("Talla:", tfTalla, fila++);
            crearTarjeta("Tipo de manga:", tfTipoManga, fila++);
            crearTarjeta("Cierre:", tfCierreRopa, fila++);
            crearCheckBox("Estampado:", cbEstampado, fila++);
        } else if (tipo.equals("Pantalon")) {
            crearTarjeta("Talla:", tfTalla, fila++);
            crearTarjeta("Cierre:", tfCierreRopa, fila++);
            crearTarjeta("Tipo de pantalon:", tfTipoPantalon, fila++);
            crearCheckBox("Bolsillos:", cbBolsillos, fila++);
        } else if (tipo.equals("Chaqueta")) {
            crearTarjeta("Talla:", tfTalla, fila++);
            crearTarjeta("Tipo de chaqueta:", tfEstilo, fila++);
            crearTarjeta("Cierre:", tfCierreRopa, fila++);
            crearCheckBox("Impermeable:", cbImpermeable, fila++);
        } else if (tipo.equals("Zapatos")) {
            crearTarjeta("Estilo:", tfEstilo, fila++);
            crearCheckBox("Personalizado:", cbPersonalizado, fila++);
            crearTarjeta("Talla zapato:", tfTallaZapato, fila++);
            crearTarjeta("Tipo suela:", tfTipoSuela, fila++);
        } else if (tipo.equals("Bolso")) {
            crearTarjeta("Estilo:", tfEstilo, fila++);
            crearCheckBox("Personalizado:", cbPersonalizado, fila++);
            crearTarjeta("Capacidad:", tfCapacidad, fila++);
            crearTarjeta("Cierre bolso:", tfCierreBolso, fila++);
        }



        // Crear botón para subir imagen
        crearBotonImagen(fila);




    }

    public void crearBotonImagen(int fila) {
        // Crear botón para subir imagen
        HBox tarjeta = new HBox();
        tarjeta.setAlignment(Pos.CENTER);
        tarjeta.setSpacing(10);
        Label label = new Label("Subir imagen:");
        label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        label.setAlignment(Pos.CENTER);
        tarjeta.getChildren().add(label);
        Button btnSubirImagen = new Button("Seleccionar imagen");
        btnSubirImagen.setOnAction(event -> {
            subirImagen(btnSubirImagen);

        });
        tarjeta.getChildren().add(btnSubirImagen);
        grid.add(tarjeta, 0, fila);

    }

    public void subirImagen( Button btnSubirImagen) {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar imagen");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg")
        );

        // Open the FileChooser dialog
        File selectedFile = fileChooser.showOpenDialog(new Stage());
        if (selectedFile != null) {
            try {
                // Define el directorio de destino
                Path targetDir = Path.of("src/main/resources/images");
                if (!Files.exists(targetDir)) {
                    Files.createDirectories(targetDir); // Crea el directorio si no existe
                }

                // Copia la imagen al directorio de destino
                Path targetPath = targetDir.resolve(selectedFile.getName());


                System.out.println("Imagen subida correctamente: " + targetPath);
                //Pop up de confirmación
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Imagen subida");
                alert.setHeaderText(null);
                alert.setContentText("Imagen subida correctamente: " + targetPath);
                alert.showAndWait();
                selectedFileG = selectedFile;
                targetPathG = targetPath;


                btnSubirImagen.setText("Imagen seleccionada: " + selectedFile.getName());


            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("Error al subir la imagen.");
            }
        } else {
            System.out.println("No se seleccionó ninguna imagen.");
        }



    }

    public void guardar() {
        try {
            Files.copy(selectedFileG.toPath(), targetPathG, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        if (cobxTipo.getValue() == null) {
            System.out.println("No se ha seleccionado ningún tipo de producto.");
            return;
        }
        String tipo = cobxTipo.getValue();
        String nombre = tfNombre.getText();
        String color = tfColor.getText();
        String material = tfMaterial.getText();
        String imagen = selectedFileG.getName();
        MaterialDAO materialDAO = new MaterialDAO();

        if (materialDAO.obtenerPorDenominacion(material) == null) {
            System.out.println("El material no existe en la base de datos.");
            materialDAO.insertar(new Material(0, material));

        }

        Material material1 = materialDAO.obtenerPorDenominacion(material);


        String marca = tfMarca.getText();
        double precio = Double.parseDouble(tfPrecio.getText());
        String descripcion = tfDescripcion.getText();


        if (tipo.equals("Camisa")) {
            String talla = tfTalla.getText();
            String tipoManga = tfTipoManga.getText();
            String cierre = tfCierreRopa.getText();
            boolean estampado = cbEstampado.isSelected();
            Camisa camisa = new Camisa(material1, 0, true, color, imagen, nombre, precio, marca, descripcion, talla, tipoManga, cierre, estampado);
            RopaDAO ropaDAO = new RopaDAO();
            ropaDAO.insertar(camisa);
        } else if (tipo.equals("Pantalon")) {
            String talla = tfTalla.getText();
            String cierre = tfCierreRopa.getText();
            String tipoPantalon = tfTipoPantalon.getText();
            boolean bolsillos = cbBolsillos.isSelected();
            Pantalon pantalon = new Pantalon(material1, 0, true, color, imagen, nombre, precio, marca, descripcion, talla, tipoPantalon, bolsillos, cierre);
            RopaDAO ropaDAO = new RopaDAO();
            ropaDAO.insertar(pantalon);


        } else if (tipo.equals("Chaqueta")) {
            String talla = tfTalla.getText();
            String cierre = tfCierreRopa.getText();

            boolean impermeable = cbImpermeable.isSelected();
            Chaqueta chaqueta = new Chaqueta(material1, 0, true, color, imagen, nombre, precio, marca, descripcion, talla, cierre, impermeable);
            RopaDAO ropaDAO = new RopaDAO();
            ropaDAO.insertar(chaqueta);

        } else if (tipo.equals("Zapatos")) {
            String estilo = tfEstilo.getText();
            boolean personalizado = cbPersonalizado.isSelected();
            int tallaZapato = Integer.parseInt(tfTallaZapato.getText());
            String tipoSuela = tfTipoSuela.getText();
            Zapatos zapatos = new Zapatos(material1, 0, true, color, imagen, nombre, precio, marca, descripcion, estilo,  personalizado, tallaZapato, tipoSuela);


        } else if (tipo.equals("Bolso")) {
            String estilo = tfEstilo.getText();
            boolean personalizado = cbPersonalizado.isSelected();
            int capacidad = Integer.parseInt(tfCapacidad.getText());
            String cierreBolso = tfCierreBolso.getText();
            Bolso bolso = new Bolso(material1, 0, true, color, imagen, nombre, precio, marca, descripcion, estilo, personalizado, cierreBolso, capacidad);

        }


    }


    public void crearTarjeta(String labelString, TextField textField, int fila) {
        HBox tarjeta = new HBox();
        tarjeta.setAlignment(Pos.CENTER);
        tarjeta.setSpacing(10);
        Label label = new Label(labelString);
        label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        label.setAlignment(Pos.CENTER);
        tarjeta.getChildren().add(label);
        tarjeta.getChildren().add(textField);
        grid.add(tarjeta, 0, fila);
    }

    public void crearCheckBox(String labelString, CheckBox checkBox, int fila) {
        HBox tarjeta = new HBox();
        tarjeta.setAlignment(Pos.CENTER);
        tarjeta.setSpacing(10);
        Label label = new Label(labelString);
        label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        label.setAlignment(Pos.CENTER);
        tarjeta.getChildren().add(label);
        tarjeta.getChildren().add(checkBox);
        grid.add(tarjeta, 0, fila);
    }


    public void salir(ActionEvent actionEvent) {
    }
}
