package iescamp.tienda;

import iescamp.tienda.modelo.Usuarios.Cliente;
import iescamp.tienda.modelo.Usuarios.MetodoPago;
import iescamp.tienda.modelo.dao.ClienteDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.util.regex.Pattern;

public class RegistroController {
    @FXML
    private AnchorPane rootPane;

    @FXML
    private TextField nombreField;
    @FXML
    private TextField apellidosField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField dniField;
    @FXML
    private DatePicker fechaNacimientoPicker;
    @FXML
    private TextField direccionField;
    @FXML
    private TextField telefonoField;
    @FXML
    private PasswordField contrasenaField;
    @FXML
    private TextField direccionEnvioField;
    @FXML
    private CheckBox tarjetaFidelizacionCheck;
    @FXML
    private Button registrarseButton;

    @FXML
    private void initialize() {

        registrarseButton.setOnAction(event -> registrarse());
    }

    private void registrarse() {
        String nombre = nombreField.getText().trim();
        String apellidos = apellidosField.getText().trim();
        String email = emailField.getText().trim();
        String dni = dniField.getText().trim();
        LocalDate fechaNacimiento = fechaNacimientoPicker.getValue();
        String direccion = direccionField.getText().trim();
        String telefono = telefonoField.getText().trim();
        String contrasena = contrasenaField.getText();
        String direccionEnvio = direccionEnvioField.getText().trim();
        boolean tieneTarjeta = tarjetaFidelizacionCheck.isSelected();

        // Validaciones básicas
        if (nombre.isEmpty() || apellidos.isEmpty() || email.isEmpty() || dni.isEmpty() || fechaNacimiento == null
                || direccion.isEmpty() || telefono.isEmpty() || contrasena.isEmpty()) {
            mostrarAlerta(AlertType.ERROR, "Campos incompletos", "Por favor, complete todos los campos obligatorios.");
            return;
        }

        if (!esEmailValido(email)) {
            mostrarAlerta(AlertType.ERROR, "Email inválido", "El formato del correo electrónico es incorrecto.");
            return;
        }

        if (!esDNICorrecto(dni)) {
            mostrarAlerta(AlertType.ERROR, "DNI inválido", "El DNI debe tener 8 dígitos y una letra.");
            return;
        }

        // Aquí iría la lógica de guardado en base de datos o envío a servidor
        // Por el momento, mostramos un mensaje de éxito
        ClienteDAO clienteDAO = new ClienteDAO();
        MetodoPago pordefecto = new MetodoPago(1, "efectivo");
        Cliente cliente = new Cliente(dni, nombre, apellidos, direccion, email, telefono, fechaNacimiento, contrasena, true, direccionEnvio, 0, tieneTarjeta, 0, pordefecto);
        clienteDAO.insertar(cliente);

        mostrarAlerta(AlertType.INFORMATION, "Registro completado", "Te has registrado correctamente");



        // Limpiar campos tras registro
        limpiarCampos();





    }

    private boolean esEmailValido(String email) {
        String regex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        return Pattern.matches(regex, email);
    }

    private boolean esDNICorrecto(String dni) {
        String regex = "^[0-9]{8}[A-Za-z]$";
        return Pattern.matches(regex, dni);
    }

    private void mostrarAlerta(AlertType tipo, String titulo, String mensaje) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void limpiarCampos() {
        nombreField.clear();
        apellidosField.clear();
        emailField.clear();
        dniField.clear();
        fechaNacimientoPicker.setValue(null);
        direccionField.clear();
        telefonoField.clear();
        contrasenaField.clear();
        direccionEnvioField.clear();
        tarjetaFidelizacionCheck.setSelected(false);
    }
    @FXML
    private void onLogin(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login_scene.fxml"));
            Parent root = null;
            root = loader.load();
            Stage stage = (Stage) rootPane.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Login");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
