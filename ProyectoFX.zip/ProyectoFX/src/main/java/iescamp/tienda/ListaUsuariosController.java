package iescamp.tienda;

import iescamp.tienda.modelo.Usuarios.Cliente;
import iescamp.tienda.modelo.Usuarios.Empleado;
import iescamp.tienda.modelo.Usuarios.Usuario;
import iescamp.tienda.modelo.dao.ClienteDAO;
import iescamp.tienda.modelo.dao.EmpleadoDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.util.ArrayList;

public class ListaUsuariosController implements Refrescable {

    @FXML
    public TableView<Cliente> tablaClientes;

    @FXML
    public TableColumn<Cliente, String> clNombre;
    @FXML
    public TableColumn<Cliente, String> clApellidos;
    @FXML
    public TableColumn<Cliente, String> clCorreo;
    @FXML
    public TableColumn<Cliente, String> clTelefono;
    @FXML
    public TableColumn<Cliente, String> clDirEnvio;
    @FXML
    public TableColumn<Cliente, String> clSaldo;
    @FXML
    public TableColumn<Cliente, String> clMPago;
    @FXML
    public TableColumn<Cliente, String> clTarjetaFIel;
    @FXML
    public TableColumn<Cliente, String> clFNacimiento;
    @FXML
    public TableColumn<Cliente, String> clDireccion;
    @FXML
    public TableColumn<Cliente, String> clDNI;

    @FXML
    public TableView tablaEmpleados;
    @FXML
    public TableColumn<Empleado, String> clDNI1;
    @FXML
    public TableColumn<Empleado, String>  clNombre1;
    @FXML
    public TableColumn<Empleado, String>  clApellidos1;
    @FXML
    public TableColumn<Empleado, String>  clCorreo1;
    @FXML
    public TableColumn<Empleado, String>  clDireccion1;
    @FXML
    public TableColumn<Empleado, String>  clTelefono1;
    @FXML
    public TableColumn<Empleado, String>  clDepartamento;
    @FXML
    public TableColumn<Empleado, String>  clPrivilegios;
    @FXML
    public TableColumn<Empleado, String>  clFNacimiento1;


    @Override
    public void refrescar() {
        cargarContenido();
    }



    private void cargarContenido() {
        ClienteDAO clienteDAO = new ClienteDAO();
        ArrayList<Cliente> clientes = (ArrayList<Cliente>) clienteDAO.obtenerTodos();
        tablaClientes.getItems().clear();

        // Set cell value factories with ObservableValue
        clNombre.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getNombre()));
        clApellidos.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getApellidos()));
        clCorreo.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getCorreoElectronico()));
        clTelefono.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getTelefono()));
        clDirEnvio.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDireccionEnvio()));
        clSaldo.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(String.valueOf(cellData.getValue().getSaldoCuenta())));
        clMPago.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getMetodoPago().getDescripcion()));
        clTarjetaFIel.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(String.valueOf(cellData.getValue().isTieneTarjetaFidelidad())));
        clFNacimiento.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getFechaNacimiento().toString()));
        clDireccion.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDireccion()));
        clDNI.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDNI()));

        // Add items to the table
        tablaClientes.getItems().addAll(clientes);



        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        ArrayList<Empleado> empleados = (ArrayList<Empleado>) empleadoDAO.obtenerTodos();
        tablaEmpleados.getItems().clear();
        // Set cell value factories with ObservableValue
        clDNI1.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDNI()));
        clNombre1.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getNombre()));
        clApellidos1.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getApellidos()));
        clCorreo1.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getCorreoElectronico()));
        clDireccion1.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDireccion()));
        clTelefono1.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getTelefono()));
        clDepartamento.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDepartamento().getNombre()));
        clPrivilegios.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(String.valueOf(cellData.getValue().isPrivilegio())));
        clFNacimiento1.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getFechaNacimiento().toString()));

        // Add items to the table
        tablaEmpleados.getItems().addAll(empleados);
    }


}
