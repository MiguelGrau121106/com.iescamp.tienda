package iescamp.tienda;

import iescamp.tienda.modelo.Articulos.Articulo;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.List;

public class CarritoController {
    @FXML
    private VBox vboxcarrito;

    @FXML
    private Label subtotalLabel, shippingLabel, totalLabel;

    @FXML
    private TextField discountCodeField;

    @FXML
    private Button applyDiscountButton;

    private List<Articulo> carrito = SessionManager.getInstancia().getCarrito();

    private double subtotal = 0;
    private double shipping = 5.0; // Ejemplo fijo
    private double descuento = 0;

    @FXML
    public void initialize() {
        cargarCarrito();

        applyDiscountButton.setOnAction(e -> aplicarDescuento());
    }




    private void cargarCarrito() {
        vboxcarrito.getChildren().clear();
        subtotal = 0;

        for (Articulo p : carrito) {
            HBox item = new HBox(10);
            item.setStyle("-fx-background-color: black; -fx-padding: 10;");
            item.setAlignment(Pos.CENTER_LEFT);

            ImageView img = new ImageView(getClass().getResource("/images/" + p.getImagen()).toExternalForm());
            img.setFitWidth(50);
            img.setFitHeight(50);
            img.setPreserveRatio(true);

            Label nombre = new Label(p.getNombre());
            nombre.setStyle("-fx-text-fill: white;");

            Region espacio = new Region();
            HBox.setHgrow(espacio, Priority.ALWAYS);

            Label precio = new Label(String.format("%.2f €", p.getPrecio()));
            precio.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");

            Button btnEliminar = new Button("🗑️");
            btnEliminar.setStyle("-fx-background-color: black; -fx-text-fill: white;");
            btnEliminar.setOnAction(e -> {
                SessionManager.getInstancia().getCarrito().remove(p);
                cargarCarrito();
            });

            item.getChildren().addAll(img, nombre, espacio, precio, btnEliminar);
            vboxcarrito.getChildren().add(item);

            subtotal += p.getPrecio();
        }

        actualizarTotales();
    }

    private void actualizarTotales() {
        subtotalLabel.setText(String.format("%.2f €", subtotal));
        shippingLabel.setText(String.format("%.2f €", shipping));

        double total = subtotal + shipping - descuento;
        if (total < 0) total = 0;

        totalLabel.setText(String.format("%.2f €", total));
    }

    private void aplicarDescuento() {
        String codigo = discountCodeField.getText().trim();
        if (codigo.equalsIgnoreCase("DESCUENTO10")) {
            descuento = subtotal * 0.10; // 10% de descuento
            actualizarTotales();
            // Podrías mostrar alerta o mensaje de éxito
        } else {
            descuento = 0;
            actualizarTotales();
            // Mensaje de código inválido si quieres
        }
    }
}