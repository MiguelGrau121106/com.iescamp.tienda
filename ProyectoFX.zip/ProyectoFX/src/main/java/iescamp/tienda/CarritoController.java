package iescamp.tienda;

import iescamp.tienda.modelo.Articulos.Articulo;
import iescamp.tienda.modelo.Pedidos.EstadoPedido;
import iescamp.tienda.modelo.Pedidos.LineaPedido;
import iescamp.tienda.modelo.Pedidos.Pedido;
import iescamp.tienda.modelo.Usuarios.Cliente;
import iescamp.tienda.modelo.dao.LineaPedidoDAO;
import iescamp.tienda.modelo.dao.PedidoDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CarritoController {
    @FXML
    public AnchorPane rootPane;
    @FXML
    public VBox vboxmain;
    @FXML
    private VBox vboxcarrito;

    @FXML
    private Label subtotalLabel, shippingLabel, totalLabel;

    @FXML
    private TextField discountCodeField;

    @FXML
    private Button PlaceOrderButton;

    private List<Articulo> carrito = SessionManager.getInstancia().getCarrito();

    private double subtotal = 0;
    private double shipping = 5.0; // Ejemplo fijo
    private double descuento = 0;

    @FXML
    public void initialize() {
        cargarCarrito();


    }




    private void cargarCarrito() {

        //ajustar el vbox main en el centro del anchorpane
        rootPane.setPrefWidth(SessionManager.getInstancia().getStage().getWidth());
        vboxmain.setAlignment(Pos.CENTER);

        vboxmain.setPrefWidth(SessionManager.getInstancia().getStage().getWidth());
        vboxmain.setPadding(new Insets(0, 500, 0, 500));
        vboxcarrito.setMaxWidth(600);

        vboxcarrito.getChildren().clear();
        subtotal = 0;

        for (Articulo p : carrito) {
            HBox item = new HBox(10);
            item.setStyle("-fx-background-color: black; -fx-padding: 10;");
            item.setAlignment(Pos.CENTER_LEFT);

            ImageView img = new ImageView(getClass().getResource("/images/" + p.getImagen()).toExternalForm());
            img.setFitWidth(100);
            img.setFitHeight(100);
            img.setPreserveRatio(true);

            Label nombre = new Label(p.getNombre());
            nombre.setStyle("-fx-text-fill: white;" +
            "-fx-font-size: 16px;");

            Region espacio = new Region();
            HBox.setHgrow(espacio, Priority.ALWAYS);

            Label precio = new Label(String.format("%.2f €", p.getPrecio()));
            precio.setStyle("-fx-text-fill: white; -fx-font-weight: bold;" +
                    "-fx-font-size: 16px;");

            Button btnEliminar = new Button("X");
            btnEliminar.setStyle("-fx-background-color: black; -fx-text-fill: white;");
            btnEliminar.setOnAction(e -> {
                SessionManager.getInstancia().getCarrito().remove(p);
                cargarCarrito();
            });

            item.getChildren().addAll(img, nombre, espacio, precio, btnEliminar);
            vboxcarrito.getChildren().add(item);

            subtotal += p.getPrecio();
        }

        actualizarTotales();
    }

    private void actualizarTotales() {
        subtotalLabel.setText(String.format("%.2f €", subtotal));
        shippingLabel.setText(String.format("%.2f €", shipping));

        double total = subtotal + shipping - descuento;
        if (total < 0) total = 0;

        totalLabel.setText(String.format("%.2f €", total));
    }



    @FXML
    public void realizarPedido(ActionEvent actionEvent) {
        PedidoDAO pedidoDAO = new PedidoDAO();
        Cliente cliente = (Cliente) SessionManager.getInstancia().getUsuario();
        if (carrito.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("El carrito está vacío. No se puede realizar el pedido.");
            alert.showAndWait();
            return;
        }
        if (cliente.getDireccionEnvio() == null || cliente.getDireccionEnvio().isEmpty()) {
            cliente.setDireccionEnvio(cliente.getDireccion());

        }
        Pedido pedido = new Pedido(0, LocalDate.now(), EstadoPedido.EN_PROCESO, cliente.getDireccionEnvio(), cliente.getMetodoPago().getCodigo(), cliente.getDNI());

        pedidoDAO.insertar(pedido);

        LineaPedidoDAO lineaPedidoDAO = new LineaPedidoDAO();
        Pedido pedido1 = pedidoDAO.obtenerPedidoSinId(pedido);
        for (Articulo articulo : carrito) {
            LineaPedido lineaPedido = new LineaPedido(articulo, pedido1);
            lineaPedidoDAO.insertar(lineaPedido);

        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Pedido realizado");
        alert.setHeaderText(null);
        alert.setContentText("El pedido se ha realizado correctamente.");
        alert.showAndWait();
    }
}