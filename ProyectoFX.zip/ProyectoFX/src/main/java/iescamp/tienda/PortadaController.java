package iescamp.tienda;

import iescamp.tienda.modelo.Usuarios.Empleado;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class PortadaController implements Refrescable{
   @FXML
    private ImageView imgPedidos;
    @FXML
    private BorderPane root;

    @FXML
    private HBox hbHeader, hbFooter, hbCenter;

    @FXML
    private VBox imgRopa, imgAltaArticulo, vboxMenu;

    @FXML
    private ImageView imgSecondHand, menuButton, imgUser, imgCarro;

    @FXML
    private ImageView AdminButton;
    @FXML
    private Button btnAñadirArticulos;

    @FXML
    private Button btnCarrito;

    @FXML
    private Button btnCatalogo;

    @FXML
    private Button btnCerrarSesion;

    @FXML
    private Button btnInicio;

    @FXML
    private Button btnPedidos;

    @FXML
    private Button btnPerfil;

    @FXML
    public void initialize() {
        // Inicializar el controlador


        if (SessionManager.getInstancia().getRoot() != null) {
            hbHeader.setVisible(false);
            vboxMenu.setVisible(false);
            hbHeader.setMinHeight(0);
            hbHeader.setPrefHeight(0);
            hbHeader.setMaxHeight(0);




        }





        if (SessionManager.getInstancia().isPrivilegios()) {
            AdminButton.setVisible(true);
            AdminButton.setDisable(false);
        }
        else {
            AdminButton.setVisible(false);
            AdminButton.setDisable(true);
        }

        if (SessionManager.getInstancia().getUsuario() instanceof Empleado){
            imgPedidos.setVisible(false);
            imgPedidos.setDisable(true);
            imgCarro.setVisible(false);
            imgCarro.setDisable(true);
        }
        else {
            imgPedidos.setVisible(true);
            imgPedidos.setDisable(false);
            imgCarro.setVisible(true);
            imgCarro.setDisable(false);
        }

        if (SessionManager.getInstancia().getRoot() == null) {
            SessionManager.getInstancia().setRoot(root);
        }
        //HACER VISIBLE SI ES USUARIO pedidos y carrito

        Object user = SessionManager.getInstancia().getUsuario();
        if (user instanceof Empleado) {
            btnPedidos.setVisible(false);
            btnPedidos.setDisable(true);
        } else {
            btnPedidos.setVisible(true);
            btnPedidos.setDisable(false);
        }

        if (user instanceof Empleado) {
            btnCarrito.setVisible(false);
            btnCarrito.setDisable(true);
        } else {
            btnCarrito.setVisible(true);
            btnCarrito.setDisable(false);
        }

        //tamaño de la ventana completa


        // Ajustar tamaño de los elementos según el tamaño de la ventana
        root.widthProperty().addListener((obs, oldVal, newVal) -> adjustLayout(newVal.doubleValue()));
        root.heightProperty().addListener((obs, oldVal, newVal) -> adjustLayout(root.getWidth()));

        // También puedes ajustar tamaños iniciales de elementos si es necesario

    }



    // Método para ajustar el tamaño de los elementos basados en el tamaño de la ventana
    private void adjustLayout(double width) {
        double scaleFactor = width / 1280; // Ajusta la referencia de tamaño que consideres
        adjustImageViews(scaleFactor);
    }

    // Ajustar tamaños de las imágenes
    private void adjustImageViews(double scaleFactor) {
        if (imgSecondHand != null) {
            imgSecondHand.setFitWidth(439 * scaleFactor);
            imgSecondHand.setFitHeight(61 * scaleFactor);
        }

        if (menuButton != null) {
            menuButton.setFitWidth(43 * scaleFactor);
            menuButton.setFitHeight(39 * scaleFactor);
        }

        if (imgUser != null) {
            imgUser.setFitWidth(43 * scaleFactor);
            imgUser.setFitHeight(43 * scaleFactor);
        }

        if (imgCarro != null) {
            imgCarro.setFitWidth(56 * scaleFactor);
            imgCarro.setFitHeight(53 * scaleFactor);
        }

        if (imgPedidos != null) {
            imgPedidos.setFitWidth(56 * scaleFactor);
            imgPedidos.setFitHeight(53 * scaleFactor);
        }
        if (AdminButton != null) {
            AdminButton.setFitWidth(56 * scaleFactor);
            AdminButton.setFitHeight(53 * scaleFactor);
        }
        if (btnCarrito != null) {
            btnCarrito.setPrefWidth(56 * scaleFactor);
            btnCarrito.setPrefHeight(50 * scaleFactor);
        }

        vboxMenu.setPrefWidth(0);
        vboxMenu.setMinWidth(0);
        vboxMenu.setVisible(false);
    }

    @FXML
    public void onInicio() {

            try {
                SessionManager.getInstancia().mostrar("Portada.fxml");




        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }





    @FXML
    public void onMenu(){

        if (vboxMenu.isVisible()) {
            vboxMenu.setVisible(false);
            vboxMenu.setPrefWidth(0);
        } else {
            vboxMenu.setVisible(true);
            vboxMenu.setPrefWidth(200);
        }


    }

    @FXML
    public void onPanelAdmin() {
        try {
            SessionManager.getInstancia().mostrar("panel_admin.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }





    @FXML
    public void onRopa() {
        try {
            SessionManager.getInstancia().mostrar("catalogo.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void onAltaArticulo(){
        try {
            SessionManager.getInstancia().mostrar("alta_producto.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public void refrescar() {


    }

    public void onUsuario(MouseEvent mouseEvent) {
        try {
            SessionManager.getInstancia().mostrar("info_usuarios.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void onCarrito(MouseEvent mouseEvent) {
        try {
            SessionManager.getInstancia().mostrar("carrito.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void onPedidos(MouseEvent mouseEvent) {
        try {
            SessionManager.getInstancia().mostrar("pedidos.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void onLogIn(ActionEvent mouseEvent) {
        SessionManager.getInstancia().cerrarSesion();
        try {
            SessionManager.getInstancia().mostrar("login_scene.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void onUsuarioMenu(ActionEvent event) {
        try {
            SessionManager.getInstancia().mostrar("info_usuarios.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void onCarritoMenu(ActionEvent event) {
        try {
            SessionManager.getInstancia().mostrar("carrito.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void onPedidosMenu(ActionEvent event) {
        try {
            SessionManager.getInstancia().mostrar("pedidos.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}