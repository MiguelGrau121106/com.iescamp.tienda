package iescamp.tienda;

import iescamp.tienda.modelo.Usuarios.Empleado;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


import java.io.IOException;

public class PortadaController implements Refrescable{
   @FXML
    private ImageView imgPedidos;
    @FXML
    private BorderPane root;

    @FXML
    private HBox hbHeader, hbFooter, hbCenter;

    @FXML
    private VBox imgRopa, imgAltaArticulo, vboxMenu;

    @FXML
    private ImageView imgSecondHand, menuButton, imgUser, imgCarro;

    @FXML
    private ImageView AdminButton;

    @FXML
    public void initialize() {
        if (SessionManager.getInstancia().isPrivilegios()) {
            AdminButton.setVisible(true);
            AdminButton.setDisable(false);
        }
        else {
            AdminButton.setVisible(false);
            AdminButton.setDisable(true);
        }

        if (SessionManager.getInstancia().getUsuario() instanceof Empleado){
            imgPedidos.setVisible(false);
            imgPedidos.setDisable(true);
            imgCarro.setVisible(false);
            imgCarro.setDisable(true);
        }
        else {
            imgPedidos.setVisible(true);
            imgPedidos.setDisable(false);
            imgCarro.setVisible(true);
            imgCarro.setDisable(false);
        }


        if (SessionManager.getInstancia().getRoot() == null) {
            SessionManager.getInstancia().setRoot(root);

        } else {
            SessionManager.getInstancia().getRoot().setCenter(hbCenter);


        }



        //tamaño de la ventana completa





        // Ajustar tamaño de los elementos según el tamaño de la ventana
        root.widthProperty().addListener((obs, oldVal, newVal) -> adjustLayout(newVal.doubleValue()));
        root.heightProperty().addListener((obs, oldVal, newVal) -> adjustLayout(root.getWidth()));

        // También puedes ajustar tamaños iniciales de elementos si es necesario

    }

    // Método para ajustar el tamaño de los elementos basados en el tamaño de la ventana
    private void adjustLayout(double width) {
        double scaleFactor = width / 1280; // Ajusta la referencia de tamaño que consideres
        adjustImageViews(scaleFactor);
    }

    // Ajustar tamaños de las imágenes
    private void adjustImageViews(double scaleFactor) {
        if (imgSecondHand != null) {
            imgSecondHand.setFitWidth(439 * scaleFactor);
            imgSecondHand.setFitHeight(61 * scaleFactor);
        }

        if (menuButton != null) {
            menuButton.setFitWidth(43 * scaleFactor);
            menuButton.setFitHeight(39 * scaleFactor);
        }






        if (imgUser != null) {
            imgUser.setFitWidth(43 * scaleFactor);
            imgUser.setFitHeight(43 * scaleFactor);
        }

        if (imgCarro != null) {
            imgCarro.setFitWidth(56 * scaleFactor);
            imgCarro.setFitHeight(53 * scaleFactor);
        }

        if (imgPedidos != null) {
            imgPedidos.setFitWidth(56 * scaleFactor);
            imgPedidos.setFitHeight(53 * scaleFactor);
        }
        if (AdminButton != null) {
            AdminButton.setFitWidth(56 * scaleFactor);
            AdminButton.setFitHeight(53 * scaleFactor);
        }
    }



    @FXML
    public void onInicio() {

            try {

                FXMLLoader loader = new FXMLLoader(getClass().getResource("Portada.fxml"));

                root = loader.load();



                // Establecer la escena en el escenario actual
                // y cargar la nueva escena


                
                if (root.getScene() == null) {
                    root.setUserData("Portada.fxml");
                } else {
                    root.getScene().setRoot(root);
                }

                Stage stage = (Stage) root.getScene().getWindow();

                if (stage == null) {
                    stage = SessionManager.getInstancia().getStage();
                }
                stage.setScene(new Scene(root));
                stage.setTitle("Portada");
                stage.setFullScreen(true);
                stage.show();



        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }





    @FXML
    public void onMenu(){

        if (((int) vboxMenu.getWidth()) > 1){
            vboxMenu.setPrefWidth(0);
            vboxMenu.setVisible(false);
        } else {


            vboxMenu.setPrefWidth(200);
            vboxMenu.setVisible(true);

        }

    }

    @FXML
    public void onPanelAdmin() {
        try {
            SessionManager.getInstancia().mostrar("panel_admin.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }





    @FXML
    public void onRopa() {
        try {
            SessionManager.getInstancia().mostrar("catalogo.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void onAltaArticulo(){
        try {
            SessionManager.getInstancia().mostrar("alta_producto.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public void refrescar() {


    }

    public void onUsuario(MouseEvent mouseEvent) {
        try {
            SessionManager.getInstancia().mostrar("info_usuarios.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void onCarrito(MouseEvent mouseEvent) {
    }

    public void onPedidos(MouseEvent mouseEvent) {

        try {
            SessionManager.getInstancia().mostrar("pedidos.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}