package iescamp.tienda;

import iescamp.tienda.modelo.Pedidos.*;
import iescamp.tienda.modelo.Articulos.Articulo;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.FlowPane;

public class PedidosController {
    @FXML
    private VBox contenedorPedidos;
    private Ventas ventas;

    public void setVentas(Ventas ventas) {
        this.ventas = ventas;
        cargarPedidos();
    }

    private void cargarPedidos() {
        contenedorPedidos.getChildren().clear();

        for (Pedido pedido : ventas.getPedidos()) {
            VBox card = new VBox(10);
            card.getStyleClass().add("pedido-card");

            // Cabecera del pedido
            Label numeroPedido = new Label("Pedido #" + pedido.getNumeroPedido());
            numeroPedido.getStyleClass().add("pedido-header");

            Label estado = new Label(pedido.getEstado().getDescripcion());
            estado.getStyleClass().add("estado-label");

            Label fecha = new Label("Fecha: " + pedido.getFechaPedido());
            Label total = new Label("Total: " + calcularTotalPedido(pedido) + " €");

            HBox header = new HBox(10, numeroPedido, estado, fecha, total);

            // Lista de artículos
            VBox listaArticulos = new VBox(5);
            for (LineaPedido linea : pedido.getLineasPedido()) {
                Articulo articulo = linea.getArticulo();

                ImageView imagen = new ImageView(new Image(articulo.getImagen()));
                imagen.setFitWidth(60);
                imagen.setFitHeight(60);

                VBox infoArticulo = new VBox(
                        new Label(articulo.getNombre()),
                        new Label("Marca: " + articulo.getMarca()),
                        new Label("Color: " + articulo.getColor()),
                        new Label("Precio: " + articulo.getPrecio() + " €")
                );

                HBox item = new HBox(10, imagen, infoArticulo);
                item.getStyleClass().add("articulo-item");
                listaArticulos.getChildren().add(item);
            }

            // Botones
            Button detalleBtn = new Button("Ver Detalle");
            detalleBtn.getStyleClass().add("boton-detalle");

            Button cancelarBtn = new Button("Cancelar");
            cancelarBtn.getStyleClass().add("boton-cancelar");
            cancelarBtn.setDisable(pedido.getEstado() != EstadoPedido.EN_PROCESO);

            FlowPane botones = new FlowPane(10, 0, detalleBtn, cancelarBtn);

            card.getChildren().addAll(header, listaArticulos, botones);

            contenedorPedidos.getChildren().add(card);
        }
    }

    private double calcularTotalPedido(Pedido pedido) {
        return pedido.getLineasPedido().stream()
                .mapToDouble(lp -> lp.getArticulo().getPrecio())
                .sum();
    }
}
